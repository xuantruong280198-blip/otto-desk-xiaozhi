#include "otto_pan_tilt.h"

#include <algorithm>
#include <cstdlib>
#include <esp_log.h>
#include <esp_err.h>
#include <freertos/task.h>

namespace {
OttoPanTilt* g_controller = nullptr;
constexpr char TAG[] = "OttoPanTilt";
constexpr ledc_mode_t kMode = LEDC_LOW_SPEED_MODE;
constexpr ledc_timer_t kTimer = LEDC_TIMER_1; // Backlight uses timer 0/channel 0.
constexpr ledc_channel_t kPanChannel = LEDC_CHANNEL_2;
constexpr ledc_channel_t kTiltChannel = LEDC_CHANNEL_3;
constexpr int kMinAngle = 45;
constexpr int kMaxAngle = 135;
constexpr int kFrameUs = 20000;
}

OttoPanTilt::OttoPanTilt(gpio_num_t pan_pin, gpio_num_t tilt_pin)
    : pan_pin_(pan_pin), tilt_pin_(tilt_pin) {
    mutex_ = xSemaphoreCreateMutex();
}

OttoPanTilt::~OttoPanTilt() {
    if (initialized_) {
        ledc_stop(kMode, kPanChannel, 0);
        ledc_stop(kMode, kTiltChannel, 0);
    }
    if (mutex_) vSemaphoreDelete(mutex_);
}

bool OttoPanTilt::ConfigureAxis(gpio_num_t pin, ledc_channel_t channel) {
    if (pin == GPIO_NUM_NC) return true;
    ledc_channel_config_t cfg = {};
    cfg.gpio_num = pin;
    cfg.speed_mode = kMode;
    cfg.channel = channel;
    cfg.intr_type = LEDC_INTR_DISABLE;
    cfg.timer_sel = kTimer;
    cfg.duty = 0;
    cfg.hpoint = 0;
    return ledc_channel_config(&cfg) == ESP_OK;
}

bool OttoPanTilt::Initialize() {
    if (pan_pin_ == GPIO_NUM_NC && tilt_pin_ == GPIO_NUM_NC) {
        ESP_LOGI(TAG, "Head servos disabled (no GPIO configured)");
        return true;
    }
    if (pan_pin_ == GPIO_NUM_NC || tilt_pin_ == GPIO_NUM_NC || pan_pin_ == tilt_pin_ || !mutex_) {
        ESP_LOGE(TAG, "Both distinct servo GPIOs are required");
        return false;
    }
    ledc_timer_config_t timer = {};
    timer.speed_mode = kMode;
    timer.duty_resolution = LEDC_TIMER_14_BIT;
    timer.timer_num = kTimer;
    timer.freq_hz = 50;
    timer.clk_cfg = LEDC_AUTO_CLK;
    if (ledc_timer_config(&timer) != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure head servo timer");
        return false;
    }
    if (!ConfigureAxis(pan_pin_, kPanChannel)) {
        ESP_LOGE(TAG, "Failed to configure pan servo GPIO %d", pan_pin_);
        return false;
    }
    if (!ConfigureAxis(tilt_pin_, kTiltChannel)) {
        ledc_stop(kMode, kPanChannel, 0);
        ESP_LOGE(TAG, "Failed to configure tilt servo GPIO %d", tilt_pin_);
        return false;
    }
    initialized_ = true;
    // Attach at neutral. Keep this conservative; calibrate mechanical center
    // and safe travel on the assembled bracket before increasing the limits.
    WritePulse(kPanChannel, AngleToPulse(90));
    WritePulse(kTiltChannel, AngleToPulse(90));
    pan_angle_ = tilt_angle_ = 90;
    ESP_LOGI(TAG, "Pan/Tilt initialized on GPIO %d/%d", pan_pin_, tilt_pin_);
    return true;
}

int OttoPanTilt::AngleToPulse(int angle) {
    angle = std::clamp(angle, kMinAngle, kMaxAngle);
    return 500 + (angle * 2000) / 180; // 500..2500 us, conservative angle clamp.
}

void OttoPanTilt::WritePulse(ledc_channel_t channel, int pulse_us) {
    const uint32_t duty = static_cast<uint32_t>((static_cast<uint64_t>(pulse_us) * ((1U << LEDC_TIMER_14_BIT) - 1U)) / kFrameUs);
    ledc_set_duty(kMode, channel, duty);
    ledc_update_duty(kMode, channel);
}

bool OttoPanTilt::SetAngles(int pan_degrees, int tilt_degrees, int speed_ms) {
    if (!initialized_ || !mutex_) return false;
    pan_degrees = std::clamp(pan_degrees, kMinAngle, kMaxAngle);
    tilt_degrees = std::clamp(tilt_degrees, kMinAngle, kMaxAngle);
    speed_ms = std::clamp(speed_ms, 100, 2000);
    if (xSemaphoreTake(mutex_, pdMS_TO_TICKS(100)) != pdTRUE) return false;
    const int start_pan = pan_angle_, start_tilt = tilt_angle_;
    const int delta = std::max(std::abs(pan_degrees - start_pan), std::abs(tilt_degrees - start_tilt));
    const int steps = std::max(1, delta);
    const int delay_ms = std::max(1, speed_ms / steps);
    for (int i = 1; i <= steps; ++i) {
        const int p = start_pan + ((pan_degrees - start_pan) * i) / steps;
        const int t = start_tilt + ((tilt_degrees - start_tilt) * i) / steps;
        WritePulse(kPanChannel, AngleToPulse(p));
        WritePulse(kTiltChannel, AngleToPulse(t));
        vTaskDelay(pdMS_TO_TICKS(delay_ms));
    }
    pan_angle_ = pan_degrees;
    tilt_angle_ = tilt_degrees;
    xSemaphoreGive(mutex_);
    return true;
}

void RegisterOttoPanTiltController(OttoPanTilt* controller) { g_controller = controller; }
OttoPanTilt* GetOttoPanTiltController() { return g_controller; }
