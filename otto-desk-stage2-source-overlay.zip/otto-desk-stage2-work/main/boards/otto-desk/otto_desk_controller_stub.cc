// Stage 1 desk profile: deliberately no servo movement code is started.
// A dedicated two-axis head controller will replace this stub in a later stage.
#include "config.h"

void InitializeOttoController(const HardwareConfig&) {
    // Intentionally empty: prevents the original six-servo walking controller
    // from attaching to NC pins or treating a desk head as a walking robot.
}
