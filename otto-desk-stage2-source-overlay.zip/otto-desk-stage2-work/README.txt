OTTO DESK - STAGE 2 SOURCE OVERLAY

This is a source overlay for the XiaoZhi source archive uploaded separately.
Extract the original xiaozhi-esp32-main.zip first, then overlay this archive
into the extracted xiaozhi-esp32-main/ directory, preserving folder paths.

Included in this stage:
- New selectable board profile: otto-desk
- ST7789 pins: CLK 5, MOSI 6, DC 15, RST 7, backlight 16, CS NC
- INMP441 pins: WS 17, SCK 18, DIN 8
- MAX98357A pins: DOUT 42, BCLK 2, LRCK 1
- Camera detection and camera use disabled by fixed NO_CAMERA profile
- Original Otto emoji display source reused
- Original six-servo walking controller intentionally not compiled; a no-op
  initializer is supplied to avoid attaching the wrong six-servo robot logic.
- GPIO40 and GPIO41 are recorded as future pan/tilt servo pins only. No servo
  driver is implemented in this stage. Do not connect servos based only on this
  profile; power and signal wiring still require a separate validated plan.

This is NOT a firmware binary and has not been compiled on ESP-IDF hardware.
It is a first-stage source overlay, not a finished robot firmware.
