#pragma once

#include <driver/gpio.h>
#include <driver/ledc.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

// Dedicated 2-axis head controller. It does not use the legacy six-servo
// Otto gait controller. Both outputs remain disabled when pins are GPIO_NUM_NC.
class OttoPanTilt {
public:
    OttoPanTilt(gpio_num_t pan_pin, gpio_num_t tilt_pin);
    ~OttoPanTilt();
    bool Initialize();
    bool SetAngles(int pan_degrees, int tilt_degrees, int speed_ms = 350);
    bool Center(int speed_ms = 350) { return SetAngles(90, 90, speed_ms); }
    bool IsEnabled() const { return initialized_; }

private:
    bool ConfigureAxis(gpio_num_t pin, ledc_channel_t channel);
    void WritePulse(ledc_channel_t channel, int pulse_us);
    static int AngleToPulse(int angle);
    gpio_num_t pan_pin_;
    gpio_num_t tilt_pin_;
    bool initialized_ = false;
    int pan_angle_ = 90;
    int tilt_angle_ = 90;
    SemaphoreHandle_t mutex_ = nullptr;
};

void RegisterOttoPanTiltController(OttoPanTilt* controller);
OttoPanTilt* GetOttoPanTiltController();
