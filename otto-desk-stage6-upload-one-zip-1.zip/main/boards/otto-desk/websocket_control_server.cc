#include "websocket_control_server.h"
#include "config.h"
#include "otto_config_store.h"
#include "otto_pan_tilt.h"
#include "mcp_server.h"
#include "application.h"
#include <esp_log.h>
#include <esp_system.h>
#include <nvs.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_http_server.h>
#include <esp_ota_ops.h>
#include <esp_app_format.h>
#include <esp_partition.h>
#include <sys/param.h>
#include <cstring>
#include <algorithm>
#include <atomic>
#include <string>
#include <cstdlib>
#include <map>

static const char* TAG = "WSControl";
static constexpr const char* CONFIG_NVS_NAMESPACE = "otto_cfg";
static constexpr const char* CONFIG_NVS_KEY = "hardware_json";
static constexpr size_t MAX_CONFIG_JSON_SIZE = 4096;
static constexpr const char* GEMINI_NVS_KEY = "gemini_api_key";
static constexpr size_t MAX_GEMINI_KEY_SIZE = 256;

static esp_err_t SendJson(httpd_req_t* req, const char* status, const char* json) {
    httpd_resp_set_status(req, status);
    httpd_resp_set_type(req, "application/json; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    return httpd_resp_sendstr(req, json);
}

static const char OTTO_CONFIG_PAGE[] = R"OTTOHTML(<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Otto Desk Config</title>
<style>body{font:16px system-ui;background:#10151d;color:#e8eef7;margin:0;padding:18px}main{max-width:760px;margin:auto}h1{font-size:24px}section{background:#1b2430;border:1px solid #344255;border-radius:14px;padding:14px;margin:14px 0}button,label.file{background:#2864dc;color:white;border:0;border-radius:9px;padding:11px 14px;margin:5px 4px 5px 0;font-weight:600;display:inline-block}button.secondary{background:#465467}button.danger{background:#a83d45}textarea{box-sizing:border-box;width:100%;min-height:240px;background:#0b1017;color:#d9f2df;border:1px solid #465467;border-radius:9px;padding:12px;font:13px ui-monospace,monospace}small,.muted{color:#aab7c8}.status{white-space:pre-wrap;padding:10px;background:#0b1017;border-radius:8px;margin-top:10px}input[type=file]{display:none}</style></head>
<body><main><h1>Otto Desk · Cấu hình phần cứng</h1><p class="muted">Kết nối cùng mạng Wi-Fi với Otto Desk. Hãy sao lưu cấu hình trước khi thay đổi.</p>
<section><h3>1. Đọc cấu hình hiện tại</h3><button id="load">Tải từ Otto</button><button class="secondary" id="export">Xuất JSON</button><label class="file" for="file">Nhập file JSON</label><input id="file" type="file" accept=".json,application/json"><p><small>Mật khẩu Wi-Fi và API key không được xuất qua cấu hình phần cứng.</small></p></section>
<section><h3>2. Tùy chỉnh chân GPIO</h3><p class="muted">Chọn chân cho từng thiết bị. Chọn “Không dùng” nếu chân đó chưa kết nối. Không được gán một GPIO cho hai chức năng.</p>
<div id="gpioGroups"></div>
<div style="margin:10px 0"><label><input id="lcdEnabled" type="checkbox"> Bật LCD1602</label> &nbsp; Địa chỉ I²C: <select id="lcdAddress"><option value="39">0x27</option><option value="63">0x3F</option></select></div>
<button class="secondary" id="applyPins">Áp dụng lựa chọn vào JSON</button><button id="savePins">Kiểm tra và lưu GPIO</button>
<p class="muted">Lưu ý: chỉ đổi GPIO khi phần cứng thực tế đã đấu đúng theo chân mới. Servo cần nguồn 5V riêng và nối chung GND.</p></section>
<section><h3>3. Nội dung JSON (nâng cao)</h3><textarea id="json" spellcheck="false" placeholder='{"config_version":1,"hardware":{}}'></textarea><button class="secondary" id="check">Kiểm tra / xem trước</button><button id="save">Xác nhận lưu cấu hình JSON</button><div id="status" class="status">Chưa tải cấu hình.</div></section>
<section><h3>4. Kiểm tra đầu Pan/Tilt</h3><p class="muted">Chỉ dùng khi đã cấu hình hai chân servo và cấp nguồn servo riêng. Góc giới hạn an toàn ban đầu 45–135 độ; cần hiệu chỉnh theo gá đầu thực tế. Servo phải dùng nguồn 5V riêng, GND nối chung với ESP32. Không cấp nguồn servo từ chân 3V3.</p><label>Quay trái / phải: <span id="panval">90</span>°</label><input id="pan" type="range" min="45" max="135" value="90" style="width:100%"><label>Cúi xuống / nhìn lên: <span id="tiltval">90</span>°</label><input id="tilt" type="range" min="45" max="135" value="90" style="width:100%"><label>Tốc độ di chuyển: <span id="speedval">450</span> ms</label><input id="headSpeed" type="range" min="100" max="2000" step="50" value="450" style="width:100%"><button id="headtest">Di chuyển đầu</button><button class="secondary" id="headcenter">Về chính giữa</button></section>
<section><h3>5. Gemini Live · API Key</h3><p class="muted">Nhập API Key trực tiếp trên mạng nội bộ của Otto. Khóa được lưu riêng trong NVS, không nằm trong JSON phần cứng và không hiển thị lại sau khi lưu.</p><p id="geminiKeyState" class="muted">Đang kiểm tra trạng thái khóa…</p><input id="geminiKey" type="password" autocomplete="new-password" placeholder="Dán Gemini API Key" style="box-sizing:border-box;width:100%;padding:12px;border-radius:8px;background:#0b1017;color:#e8eef7;border:1px solid #465467"><button id="saveGeminiKey">Lưu API Key</button><button class="secondary" id="clearGeminiKey">Xóa API Key</button><p class="muted">Lưu ý: NVS không tự động mã hóa bí mật. Muốn bảo vệ khóa khi người khác có quyền đọc flash, cần bật ESP32 flash encryption và secure boot. Chỉ mở trang này trên mạng Wi-Fi tin cậy.</p></section>
<section><h3>6. Gemini Live · Điều khiển phiên</h3><p class="muted">Kết nối trực tiếp từ ESP32 tới Gemini Live. Cần lưu API Key trước. Khi kết nối, Otto dùng mic và loa để hội thoại; nút ngắt sẽ dừng phiên.</p><p id="geminiSessionState" class="muted">Chưa kiểm tra trạng thái.</p><button id="geminiConnect">Kết nối Gemini</button><button class="danger" id="geminiDisconnect">Ngắt kết nối</button></section>
<section><h3>7. Cập nhật firmware OTA</h3><p class="muted">Chọn file firmware .bin được build đúng cho bo mạch này. Thiết bị sẽ ghi vào phân vùng OTA dự phòng, xác thực ảnh rồi mới chọn khởi động từ bản mới. Không tắt nguồn trong quá trình cập nhật. Chỉ dùng trên Wi-Fi tin cậy.</p><input id="otaFile" type="file" accept=".bin,application/octet-stream" style="display:block;margin:10px 0"><button id="otaUpload">Cập nhật firmware</button><progress id="otaProgress" max="100" value="0" style="width:100%;height:18px"></progress><p id="otaState" class="muted">Chưa chọn firmware.</p></section>
<section><h3>8. Khởi động lại</h3><p class="muted">Chỉ khởi động lại sau khi lưu thành công. Thiết bị sẽ ngắt kết nối trong quá trình khởi động.</p><button class="danger" id="restart">Khởi động lại Otto</button></section>
</main><script>
const $=id=>document.getElementById(id), status=t=>$('status').textContent=t;
let loaded=null, saved=false;
const pinGroups=[
 {title:'Màn hình ST7789',fields:[['display_clk','CLK',5],['display_mosi','MOSI',6],['display_dc','DC',15],['display_rst','RST',7],['display_backlight','Backlight',16],['display_cs','CS',-1]]},
 {title:'Micro INMP441',fields:[['mic_ws','WS',17],['mic_sck','SCK',18],['mic_din','DIN',8]]},
 {title:'Loa MAX98357A',fields:[['speaker_dout','DOUT',42],['speaker_bclk','BCLK',2],['speaker_lrck','LRCK',1]]},
 {title:'LCD1602 (I²C)',fields:[['i2c_sda','SDA',-1],['i2c_scl','SCL',-1]]},
 {title:'Servo đầu Pan/Tilt',fields:[['pan_servo','Pan',40],['tilt_servo','Tilt',41]]}
];
const usablePins=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,21,38,39,40,41,42,47,48];
function renderPinControls(hw={}){
 const root=$('gpioGroups');root.innerHTML='';
 for(const group of pinGroups){const box=document.createElement('div');box.style.cssText='border-top:1px solid #344255;padding:10px 0';
 const h=document.createElement('h4');h.textContent=group.title;box.appendChild(h);
 for(const [key,label,def] of group.fields){const row=document.createElement('label');row.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:12px;margin:9px 0';const name=document.createElement('span');name.textContent=label;const sel=document.createElement('select');sel.dataset.pin=key;sel.style.cssText='min-width:120px;padding:8px;border-radius:8px;background:#0b1017;color:#e8eef7;border:1px solid #465467';
 const values=[-1,...usablePins];for(const pin of values){const op=document.createElement('option');op.value=String(pin);op.textContent=pin===-1?'Không dùng':'GPIO '+pin;sel.appendChild(op)}const val=Object.prototype.hasOwnProperty.call(hw,key)?Number(hw[key]):def;sel.value=String(val);row.append(name,sel);box.appendChild(row)}root.appendChild(box)}
 $('lcdEnabled').checked=!!hw.lcd1602_enabled;$('lcdAddress').value=String(hw.lcd1602_address===63?63:39);
}
function pinConfigFromControls(){const hw={};for(const sel of document.querySelectorAll('[data-pin]'))hw[sel.dataset.pin]=Number(sel.value);hw.lcd1602_enabled=$('lcdEnabled').checked;hw.lcd1602_address=Number($('lcdAddress').value);return hw}
function validatePinControls(){const hw=pinConfigFromControls(),seen={};for(const [key,value] of Object.entries(hw)){if(key==='lcd1602_enabled'||key==='lcd1602_address'||value===-1)continue;if(seen[value])throw Error('GPIO '+value+' bị trùng: '+seen[value]+' và '+key);seen[value]=key}if(hw.lcd1602_enabled&&(hw.i2c_sda===-1||hw.i2c_scl===-1))throw Error('Bật LCD1602 thì phải chọn cả SDA và SCL');if((hw.pan_servo===-1)!==(hw.tilt_servo===-1))throw Error('Pan và Tilt phải cùng được cấu hình hoặc cùng để Không dùng');return hw}
function mergeControlsIntoJson(){const current=$('json').value.trim()?JSON.parse($('json').value):{config_version:1,hardware:{}};if(!current||typeof current!=='object'||Array.isArray(current))throw Error('JSON gốc phải là object');current.config_version=1;current.hardware={...(current.hardware||{}),...validatePinControls()};$('json').value=JSON.stringify(current,null,2);return current}
async function api(path,opt={}){const r=await fetch(path,{cache:'no-store',...opt});const t=await r.text();let j;try{j=JSON.parse(t)}catch{throw Error('Phản hồi không phải JSON: '+t.slice(0,120))}if(!r.ok)throw Error(j.error||('HTTP '+r.status));return j}
renderPinControls({});
async function refreshGeminiKeyState(){try{const r=await api('/api/gemini-key');$('geminiKeyState').textContent=r.configured?'API Key đã được lưu (không hiển thị giá trị).':'Chưa có API Key.'}catch(e){$('geminiKeyState').textContent='Không đọc được trạng thái API Key: '+e.message}}
refreshGeminiKeyState();
$('saveGeminiKey').onclick=async()=>{const key=$('geminiKey').value.trim();if(key.length<20||key.length>256){status('API Key có độ dài không hợp lệ.');return}if(!confirm('Lưu API Key vào bộ nhớ riêng của Otto?'))return;try{const r=await api('/api/gemini-key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:key})});$('geminiKey').value='';status(r.saved?'Đã lưu API Key. Khởi động lại hoặc kết nối lại Gemini để sử dụng.':'Không lưu được API Key.');refreshGeminiKeyState()}catch(e){status('Lưu API Key thất bại: '+e.message)}};
$('clearGeminiKey').onclick=async()=>{if(!confirm('Xóa API Key Gemini đã lưu trên Otto?'))return;try{await api('/api/gemini-key',{method:'DELETE'});$('geminiKey').value='';status('Đã xóa API Key Gemini.');refreshGeminiKeyState()}catch(e){status('Xóa API Key thất bại: '+e.message)}};
async function refreshGeminiSession(){try{const r=await api('/api/gemini-session');$('geminiSessionState').textContent=r.connected?'Gemini Live: Đã kết nối':'Gemini Live: Chưa kết nối'}catch(e){$('geminiSessionState').textContent='Không đọc được trạng thái: '+e.message}}
$('geminiConnect').onclick=async()=>{try{$('geminiSessionState').textContent='Đang kết nối…';const r=await api('/api/gemini-session',{method:'POST'});$('geminiSessionState').textContent=r.started?'Đã mở WebSocket; đang chờ setupComplete…':'Không thể bắt đầu phiên';refreshGeminiSession()}catch(e){$('geminiSessionState').textContent='Kết nối thất bại: '+e.message}};
$('geminiDisconnect').onclick=async()=>{try{await api('/api/gemini-session',{method:'DELETE'});refreshGeminiSession()}catch(e){$('geminiSessionState').textContent='Ngắt kết nối thất bại: '+e.message}};
refreshGeminiSession();setInterval(refreshGeminiSession,3000);
$('load').onclick=async()=>{try{const j=await api('/api/config');loaded=j;$('json').value=JSON.stringify(j,null,2);renderPinControls(j.hardware||{});saved=false;status('Đã tải cấu hình từ Otto.')}catch(e){status('Lỗi: '+e.message)}};
$('check').onclick=()=>{try{const j=JSON.parse($('json').value);if(!j||Array.isArray(j)||typeof j!=='object')throw Error('Gốc JSON phải là object');if(j.config_version!==1)throw Error('config_version phải bằng 1');if(!j.hardware||Array.isArray(j.hardware)||typeof j.hardware!=='object')throw Error('Thiếu object hardware');if('wifi_password'in j||'api_key'in j)throw Error('Không đưa thông tin bí mật vào file cấu hình phần cứng');const preview=JSON.stringify(j,null,2);status('JSON hợp lệ về cú pháp và cấu trúc cơ bản.\n\nXem trước nội dung sẽ lưu:\n'+preview);return j}catch(e){status('Không hợp lệ: '+e.message);return null}};
$('save').onclick=async()=>{const j=$('check').onclick();if(!j)return;if(!confirm('Xác nhận ghi cấu hình này vào bộ nhớ Otto? Cấu hình cũ sẽ được thay thế.'))return;try{const r=await api('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(j)});saved=!!r.saved;status(saved?'Đã lưu vào NVS. Cần khởi động lại để cấu hình mới có hiệu lực.':'Không xác nhận được trạng thái lưu.')}catch(e){saved=false;status('Lưu thất bại; cấu hình cũ được giữ nguyên nếu NVS không ghi thành công.\n'+e.message)}};
$('applyPins').onclick=()=>{try{mergeControlsIntoJson();status('Đã cập nhật JSON từ các lựa chọn GPIO. Hãy kiểm tra rồi nhấn lưu.')}catch(e){status('Cấu hình GPIO không hợp lệ: '+e.message)}};
$('savePins').onclick=async()=>{try{$('json').value=JSON.stringify(mergeControlsIntoJson(),null,2);const j=$('check').onclick();if(!j)return;if(!confirm('Ghi cấu hình GPIO này vào bộ nhớ Otto?'))return;const r=await api('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(j)});saved=!!r.saved;status(saved?'Đã lưu GPIO vào NVS. Khởi động lại để áp dụng.':'Không xác nhận được trạng thái lưu.')}catch(e){status('Không thể lưu GPIO: '+e.message)}};
$('export').onclick=()=>{try{const j=JSON.parse($('json').value);const blob=new Blob([JSON.stringify(j,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='otto-desk-hardware-config.json';a.click();URL.revokeObjectURL(a.href);status('Đã tạo file JSON để tải về.')}catch(e){status('Không thể xuất: JSON chưa hợp lệ. '+e.message)}};
$('file').onchange=async ev=>{const f=ev.target.files[0];if(!f)return;try{$('json').value=await f.text();saved=false;status('Đã nạp file vào khung soạn thảo. Hãy kiểm tra trước khi lưu.')}catch(e){status('Không đọc được file: '+e.message)}ev.target.value=''};
$('pan').oninput=()=> $('panval').textContent=$('pan').value;
$('tilt').oninput=()=> $('tiltval').textContent=$('tilt').value;
$('headSpeed').oninput=()=> $('speedval').textContent=$('headSpeed').value;
async function moveHead(p,t){try{const r=await api('/api/head',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pan:p,tilt:t,speed_ms:Number($('headSpeed').value)})});status(r.ok?'Đã gửi lệnh Pan/Tilt.':JSON.stringify(r))}catch(e){status('Pan/Tilt: '+e.message)}}
$('headtest').onclick=()=>moveHead(Number($('pan').value),Number($('tilt').value));
$('headcenter').onclick=()=>{ $('pan').value=90; $('tilt').value=90; $('panval').textContent='90'; $('tiltval').textContent='90'; moveHead(90,90); };
$('otaUpload').onclick=()=>{const f=$('otaFile').files[0];if(!f){$('otaState').textContent='Hãy chọn file .bin trước.';return}if(!f.name.toLowerCase().endsWith('.bin')){$('otaState').textContent='Chỉ chấp nhận file .bin.';return}if(!confirm('Cập nhật firmware từ '+f.name+' ('+f.size+' bytes)? Không tắt nguồn trong quá trình này.'))return;const xhr=new XMLHttpRequest();xhr.open('POST','/api/ota');xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.upload.onprogress=e=>{if(e.lengthComputable){const pct=Math.round(e.loaded*100/e.total);$('otaProgress').value=pct;$('otaState').textContent='Đang tải và ghi firmware: '+pct+'%'}};xhr.onload=()=>{let r={};try{r=JSON.parse(xhr.responseText)}catch{}if(xhr.status>=200&&xhr.status<300&&r.ok){$('otaProgress').value=100;$('otaState').textContent='Đã xác thực firmware và chọn phân vùng khởi động. Hãy khởi động lại Otto để chạy bản mới.'}else{$('otaState').textContent='OTA thất bại: '+(r.error||('HTTP '+xhr.status))}};xhr.onerror=()=>{$('otaState').textContent='Mất kết nối trong lúc OTA. Kiểm tra trạng thái thiết bị trước khi thử lại.'};$('otaProgress').value=0;$('otaState').textContent='Đang bắt đầu OTA…';xhr.send(f)};
$('restart').onclick=async()=>{if(!confirm('Khởi động lại Otto Desk ngay bây giờ?'))return;try{await api('/api/restart',{method:'POST'});status('Đã gửi yêu cầu khởi động lại. Hãy chờ thiết bị kết nối Wi-Fi trở lại.')}catch(e){status('Không gửi được yêu cầu: '+e.message)}};
</script></body></html>)OTTOHTML";

static esp_err_t config_page_handler(httpd_req_t* req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    return httpd_resp_send(req, OTTO_CONFIG_PAGE, HTTPD_RESP_USE_STRLEN);
}

static void RestartTask(void*) {
    vTaskDelay(pdMS_TO_TICKS(700));
    esp_restart();
}

WebSocketControlServer* WebSocketControlServer::instance_ = nullptr;

WebSocketControlServer::WebSocketControlServer() : server_handle_(nullptr) {
    instance_ = this;
}

WebSocketControlServer::~WebSocketControlServer() {
    Stop();
    instance_ = nullptr;
}

esp_err_t WebSocketControlServer::ws_handler(httpd_req_t *req) {
    if (instance_ == nullptr) {
        return ESP_FAIL;
    }
    
    if (req->method == HTTP_GET) {
        ESP_LOGI(TAG, "Handshake done, the new connection was opened");
        instance_->AddClient(req);
        return ESP_OK;
    }
    
    httpd_ws_frame_t ws_pkt;
    uint8_t *buf = NULL;
    memset(&ws_pkt, 0, sizeof(httpd_ws_frame_t));
    ws_pkt.type = HTTPD_WS_TYPE_TEXT;
    
    /* Set max_len = 0 to get the frame len */
    esp_err_t ret = httpd_ws_recv_frame(req, &ws_pkt, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "httpd_ws_recv_frame failed to get frame len with %d", ret);
        return ret;
    }
    ESP_LOGI(TAG, "frame len is %d", ws_pkt.len);
    
    if (ws_pkt.len) {
        /* ws_pkt.len + 1 is for NULL termination as we are expecting a string */
        buf = (uint8_t*)calloc(1, ws_pkt.len + 1);
        if (buf == NULL) {
            ESP_LOGE(TAG, "Failed to calloc memory for buf");
            return ESP_ERR_NO_MEM;
        }
        ws_pkt.payload = buf;
        /* Set max_len = ws_pkt.len to get the frame payload */
        ret = httpd_ws_recv_frame(req, &ws_pkt, ws_pkt.len);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "httpd_ws_recv_frame failed with %d", ret);
            free(buf);
            return ret;
        }
        ESP_LOGI(TAG, "Got packet with message: %s", ws_pkt.payload);
    }
    
    ESP_LOGI(TAG, "Packet type: %d", ws_pkt.type);
    
    if (ws_pkt.type == HTTPD_WS_TYPE_CLOSE) {
        ESP_LOGI(TAG, "WebSocket close frame received");
        instance_->RemoveClient(req);
        free(buf);
        return ESP_OK;
    }
    
    if (ws_pkt.type == HTTPD_WS_TYPE_TEXT) {
        if (ws_pkt.len > 0 && buf != nullptr) {
            buf[ws_pkt.len] = '\0';
            instance_->HandleMessage(req, (const char*)buf, ws_pkt.len);
        }
    } else {
        ESP_LOGW(TAG, "Unsupported frame type: %d", ws_pkt.type);
    }
    
    free(buf);
    return ESP_OK;
}

bool WebSocketControlServer::Start(int port) {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = port;
    config.max_open_sockets = 7;
    config.ctrl_port = 32769;

    httpd_uri_t ws_uri = {
        .uri = "/ws",
        .method = HTTP_GET,
        .handler = ws_handler,
        .user_ctx = nullptr,
        .is_websocket = true
    };

    if (httpd_start(&server_handle_, &config) == ESP_OK) {
        httpd_register_uri_handler(server_handle_, &ws_uri);

        httpd_uri_t config_page_uri = {
            .uri = "/", .method = HTTP_GET,
            .handler = config_page_handler, .user_ctx = nullptr
        };
        httpd_register_uri_handler(server_handle_, &config_page_uri);

        httpd_uri_t config_get_uri = {
            .uri = "/api/config", .method = HTTP_GET,
            .handler = config_get_handler, .user_ctx = nullptr
        };
        httpd_uri_t config_post_uri = {
            .uri = "/api/config", .method = HTTP_POST,
            .handler = config_post_handler, .user_ctx = nullptr
        };
        httpd_uri_t restart_uri = {
            .uri = "/api/restart", .method = HTTP_POST,
            .handler = restart_post_handler, .user_ctx = nullptr
        };
        httpd_register_uri_handler(server_handle_, &config_get_uri);
        httpd_register_uri_handler(server_handle_, &config_post_uri);
        httpd_register_uri_handler(server_handle_, &restart_uri);
        httpd_uri_t head_uri = {
            .uri = "/api/head", .method = HTTP_POST,
            .handler = head_post_handler, .user_ctx = nullptr
        };
        httpd_register_uri_handler(server_handle_, &head_uri);
        httpd_uri_t gemini_key_get_uri = {
            .uri = "/api/gemini-key", .method = HTTP_GET,
            .handler = gemini_key_get_handler, .user_ctx = nullptr
        };
        httpd_uri_t gemini_key_post_uri = {
            .uri = "/api/gemini-key", .method = HTTP_POST,
            .handler = gemini_key_post_handler, .user_ctx = nullptr
        };
        httpd_uri_t gemini_key_delete_uri = {
            .uri = "/api/gemini-key", .method = HTTP_DELETE,
            .handler = gemini_key_delete_handler, .user_ctx = nullptr
        };
        httpd_register_uri_handler(server_handle_, &gemini_key_get_uri);
        httpd_register_uri_handler(server_handle_, &gemini_key_post_uri);
        httpd_register_uri_handler(server_handle_, &gemini_key_delete_uri);
        httpd_uri_t gemini_session_get_uri = { .uri = "/api/gemini-session", .method = HTTP_GET, .handler = gemini_session_get_handler, .user_ctx = nullptr };
        httpd_uri_t gemini_session_post_uri = { .uri = "/api/gemini-session", .method = HTTP_POST, .handler = gemini_session_post_handler, .user_ctx = nullptr };
        httpd_uri_t gemini_session_delete_uri = { .uri = "/api/gemini-session", .method = HTTP_DELETE, .handler = gemini_session_delete_handler, .user_ctx = nullptr };
        httpd_register_uri_handler(server_handle_, &gemini_session_get_uri);
        httpd_register_uri_handler(server_handle_, &gemini_session_post_uri);
        httpd_register_uri_handler(server_handle_, &gemini_session_delete_uri);
        httpd_uri_t ota_upload_uri = { .uri = "/api/ota", .method = HTTP_POST, .handler = ota_upload_post_handler, .user_ctx = nullptr };
        httpd_register_uri_handler(server_handle_, &ota_upload_uri);
        ESP_LOGI(TAG, "WebSocket/config API started on port %d", port);
        return true;
    }

    ESP_LOGE(TAG, "Failed to start WebSocket server");
    return false;
}

esp_err_t WebSocketControlServer::config_get_handler(httpd_req_t* req) {
    nvs_handle_t nvs;
    esp_err_t err = nvs_open(CONFIG_NVS_NAMESPACE, NVS_READONLY, &nvs);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        return SendJson(req, "200 OK", "{\"config_version\":1,\"hardware\":{}} ");
    }
    if (err != ESP_OK) return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"nvs_open_failed\"}");

    size_t required = 0;
    err = nvs_get_str(nvs, CONFIG_NVS_KEY, nullptr, &required);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        nvs_close(nvs);
        return SendJson(req, "200 OK", "{\"config_version\":1,\"hardware\":{}} ");
    }
    if (err != ESP_OK || required == 0 || required > MAX_CONFIG_JSON_SIZE + 1) {
        nvs_close(nvs);
        return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"stored_config_invalid\"}");
    }
    char* value = static_cast<char*>(malloc(required));
    if (!value) { nvs_close(nvs); return ESP_ERR_NO_MEM; }
    err = nvs_get_str(nvs, CONFIG_NVS_KEY, value, &required);
    nvs_close(nvs);
    if (err != ESP_OK) { free(value); return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"nvs_read_failed\"}"); }
    httpd_resp_set_type(req, "application/json; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    esp_err_t result = httpd_resp_sendstr(req, value);
    free(value);
    return result;
}

esp_err_t WebSocketControlServer::config_post_handler(httpd_req_t* req) {
    if (req->content_len <= 0 || req->content_len > MAX_CONFIG_JSON_SIZE) {
        return SendJson(req, "413 Payload Too Large", "{\"ok\":false,\"error\":\"invalid_config_size\"}");
    }
    char* body = static_cast<char*>(calloc(1, req->content_len + 1));
    if (!body) return ESP_ERR_NO_MEM;
    int received = 0;
    while (received < req->content_len) {
        int r = httpd_req_recv(req, body + received, req->content_len - received);
        if (r <= 0) { free(body); return SendJson(req, "400 Bad Request", "{\"ok\":false,\"error\":\"incomplete_body\"}"); }
        received += r;
    }

    cJSON* root = cJSON_ParseWithLength(body, req->content_len);
    if (!root || !cJSON_IsObject(root)) {
        if (root) cJSON_Delete(root);
        free(body);
        return SendJson(req, "400 Bad Request", "{\"ok\":false,\"error\":\"invalid_json_object\"}");
    }
    cJSON* version = cJSON_GetObjectItemCaseSensitive(root, "config_version");
    cJSON* hardware = cJSON_GetObjectItemCaseSensitive(root, "hardware");
    if (!cJSON_IsNumber(version) || version->valueint != 1 || !cJSON_IsObject(hardware)) {
        cJSON_Delete(root); free(body);
        return SendJson(req, "422 Unprocessable Entity", "{\"ok\":false,\"error\":\"unsupported_schema\"}");
    }
    // Never persist credentials through this hardware-config endpoint.
    if (cJSON_GetObjectItemCaseSensitive(root, "wifi_password") ||
        cJSON_GetObjectItemCaseSensitive(root, "api_key")) {
        cJSON_Delete(root); free(body);
        return SendJson(req, "422 Unprocessable Entity", "{\"ok\":false,\"error\":\"credentials_not_allowed\"}");
    }
    char* normalized = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    free(body);
    if (!normalized) return ESP_ERR_NO_MEM;

    // Reject GPIO values that cannot exist on ESP32-S3 and any duplicate
    // assignment before replacing the last known-good NVS record.
    HardwareConfig candidate = NON_CAMERA_VERSION_CONFIG;
    if (!otto_desk_config::ApplyJson(normalized, candidate)) {
        free(normalized);
        return SendJson(req, "422 Unprocessable Entity", "{\"ok\":false,\"error\":\"invalid_or_conflicting_gpio\"}");
    }

    nvs_handle_t nvs;
    esp_err_t err = nvs_open(CONFIG_NVS_NAMESPACE, NVS_READWRITE, &nvs);
    if (err == ESP_OK) {
        err = nvs_set_str(nvs, CONFIG_NVS_KEY, normalized);
        if (err == ESP_OK) err = nvs_commit(nvs);
        nvs_close(nvs);
    }
    free(normalized);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to persist hardware config: %s", esp_err_to_name(err));
        return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"config_save_failed\"}");
    }
    return SendJson(req, "200 OK", "{\"ok\":true,\"saved\":true,\"restart_required\":true}");
}


esp_err_t WebSocketControlServer::gemini_key_get_handler(httpd_req_t* req) {
    nvs_handle_t nvs;
    esp_err_t err = nvs_open(CONFIG_NVS_NAMESPACE, NVS_READONLY, &nvs);
    if (err == ESP_ERR_NVS_NOT_FOUND) return SendJson(req, "200 OK", "{\"configured\":false}");
    if (err != ESP_OK) return SendJson(req, "500 Internal Server Error", "{\"error\":\"nvs_open_failed\"}");
    size_t required = 0;
    err = nvs_get_str(nvs, GEMINI_NVS_KEY, nullptr, &required);
    nvs_close(nvs);
    if (err == ESP_ERR_NVS_NOT_FOUND) return SendJson(req, "200 OK", "{\"configured\":false}");
    if (err != ESP_OK || required < 2 || required > MAX_GEMINI_KEY_SIZE + 1)
        return SendJson(req, "500 Internal Server Error", "{\"error\":\"stored_key_invalid\"}");
    return SendJson(req, "200 OK", "{\"configured\":true}");
}

esp_err_t WebSocketControlServer::gemini_key_post_handler(httpd_req_t* req) {
    if (req->content_len <= 0 || req->content_len > 320)
        return SendJson(req, "413 Payload Too Large", "{\"error\":\"invalid_body_size\"}");
    char* body = static_cast<char*>(calloc(1, req->content_len + 1));
    if (!body) return ESP_ERR_NO_MEM;
    int received = 0;
    while (received < req->content_len) {
        int r = httpd_req_recv(req, body + received, req->content_len - received);
        if (r <= 0) { free(body); return SendJson(req, "400 Bad Request", "{\"error\":\"incomplete_body\"}"); }
        received += r;
    }
    cJSON* root = cJSON_ParseWithLength(body, req->content_len);
    // The HTTP request buffer contains the submitted secret; clear it before release.
    memset(body, 0, req->content_len + 1);
    free(body);
    cJSON* item = root ? cJSON_GetObjectItemCaseSensitive(root, "api_key") : nullptr;
    bool valid = cJSON_IsString(item) && item->valuestring;
    std::string key = valid ? item->valuestring : "";
    cJSON_Delete(root);
    if (!valid || key.size() < 20 || key.size() > MAX_GEMINI_KEY_SIZE)
        return SendJson(req, "422 Unprocessable Entity", "{\"error\":\"invalid_api_key\"}");
    for (unsigned char c : key) {
        if (c < 0x21 || c > 0x7e)
            return SendJson(req, "422 Unprocessable Entity", "{\"error\":\"invalid_api_key_characters\"}");
    }
    nvs_handle_t nvs;
    esp_err_t err = nvs_open(CONFIG_NVS_NAMESPACE, NVS_READWRITE, &nvs);
    if (err == ESP_OK) {
        err = nvs_set_str(nvs, GEMINI_NVS_KEY, key.c_str());
        if (err == ESP_OK) err = nvs_commit(nvs);
        nvs_close(nvs);
    }
    // Best-effort overwrite of the temporary heap copy before release.
    std::fill(key.begin(), key.end(), '\0');
    if (err != ESP_OK) return SendJson(req, "500 Internal Server Error", "{\"error\":\"key_save_failed\"}");
    return SendJson(req, "200 OK", "{\"ok\":true,\"saved\":true}");
}

esp_err_t WebSocketControlServer::gemini_key_delete_handler(httpd_req_t* req) {
    nvs_handle_t nvs;
    esp_err_t err = nvs_open(CONFIG_NVS_NAMESPACE, NVS_READWRITE, &nvs);
    if (err == ESP_ERR_NVS_NOT_FOUND) return SendJson(req, "200 OK", "{\"ok\":true,\"deleted\":true}");
    if (err != ESP_OK) return SendJson(req, "500 Internal Server Error", "{\"error\":\"nvs_open_failed\"}");
    err = nvs_erase_key(nvs, GEMINI_NVS_KEY);
    if (err == ESP_ERR_NVS_NOT_FOUND) err = ESP_OK;
    if (err == ESP_OK) err = nvs_commit(nvs);
    nvs_close(nvs);
    if (err != ESP_OK) return SendJson(req, "500 Internal Server Error", "{\"error\":\"key_delete_failed\"}");
    return SendJson(req, "200 OK", "{\"ok\":true,\"deleted\":true}");
}

esp_err_t WebSocketControlServer::gemini_session_get_handler(httpd_req_t* req) {
    const bool connected = Application::GetInstance().IsGeminiLiveConnected();
    return SendJson(req, "200 OK", connected ? "{\"connected\":true}" : "{\"connected\":false}");
}

esp_err_t WebSocketControlServer::gemini_session_post_handler(httpd_req_t* req) {
    if (!Application::GetInstance().ConnectGeminiLive())
        return SendJson(req, "503 Service Unavailable", "{\"started\":false,\"error\":\"connect_failed_or_api_key_missing\"}");
    return SendJson(req, "200 OK", "{\"started\":true}");
}

esp_err_t WebSocketControlServer::gemini_session_delete_handler(httpd_req_t* req) {
    Application::GetInstance().DisconnectGeminiLive();
    return SendJson(req, "200 OK", "{\"disconnected\":true}");
}

esp_err_t WebSocketControlServer::ota_upload_post_handler(httpd_req_t* req) {
    // This endpoint accepts a raw application .bin body, not multipart form data.
    static std::atomic<bool> update_in_progress{false};
    bool expected = false;
    if (!update_in_progress.compare_exchange_strong(expected, true)) {
        return SendJson(req, "409 Conflict", "{\"ok\":false,\"error\":\"ota_busy\"}");
    }
    auto finish = [&]() { update_in_progress.store(false); };

    const esp_partition_t* partition = esp_ota_get_next_update_partition(nullptr);
    if (!partition) {
        finish();
        return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"no_update_partition\"}");
    }
    const size_t image_size = static_cast<size_t>(req->content_len);
    constexpr size_t MIN_IMAGE_SIZE = sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t) + sizeof(esp_app_desc_t);
    if (req->content_len <= 0 || image_size < MIN_IMAGE_SIZE || image_size > partition->size) {
        finish();
        return SendJson(req, "413 Payload Too Large", "{\"ok\":false,\"error\":\"invalid_firmware_size\"}");
    }

    esp_ota_handle_t handle = 0;
    esp_err_t err = esp_ota_begin(partition, image_size, &handle);
    if (err != ESP_OK) {
        finish();
        ESP_LOGE(TAG, "esp_ota_begin failed: %s", esp_err_to_name(err));
        return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"ota_begin_failed\"}");
    }

    uint8_t buffer[4096];
    size_t received_total = 0;
    bool first_byte_checked = false;
    while (received_total < image_size) {
        const size_t remaining = image_size - received_total;
        const size_t want = std::min(sizeof(buffer), remaining);
        int received = httpd_req_recv(req, reinterpret_cast<char*>(buffer), want);
        if (received == HTTPD_SOCK_ERR_TIMEOUT) continue;
        if (received <= 0) {
            esp_ota_abort(handle);
            finish();
            return SendJson(req, "400 Bad Request", "{\"ok\":false,\"error\":\"upload_incomplete\"}");
        }
        if (!first_byte_checked) {
            first_byte_checked = true;
            if (buffer[0] != 0xE9) {
                esp_ota_abort(handle);
                finish();
                return SendJson(req, "415 Unsupported Media Type", "{\"ok\":false,\"error\":\"not_esp_image\"}");
            }
        }
        err = esp_ota_write(handle, buffer, static_cast<size_t>(received));
        if (err != ESP_OK) {
            esp_ota_abort(handle);
            finish();
            ESP_LOGE(TAG, "esp_ota_write failed: %s", esp_err_to_name(err));
            return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"ota_write_failed\"}");
        }
        received_total += static_cast<size_t>(received);
    }

    err = esp_ota_end(handle); // Includes image integrity / format validation.
    if (err != ESP_OK) {
        finish();
        ESP_LOGE(TAG, "esp_ota_end validation failed: %s", esp_err_to_name(err));
        return SendJson(req, "422 Unprocessable Entity", "{\"ok\":false,\"error\":\"firmware_validation_failed\"}");
    }
    err = esp_ota_set_boot_partition(partition);
    if (err != ESP_OK) {
        finish();
        ESP_LOGE(TAG, "esp_ota_set_boot_partition failed: %s", esp_err_to_name(err));
        return SendJson(req, "500 Internal Server Error", "{\"ok\":false,\"error\":\"set_boot_partition_failed\"}");
    }
    finish();
    ESP_LOGI(TAG, "OTA image accepted (%u bytes), boot partition set to %s", received_total, partition->label);
    return SendJson(req, "200 OK", "{\"ok\":true,\"validated\":true,\"reboot_required\":true}");
}

esp_err_t WebSocketControlServer::head_post_handler(httpd_req_t* req) {
    if (req->content_len <= 0 || req->content_len > 256) {
        return SendJson(req, "413 Payload Too Large", "{\"ok\":false,\"error\":\"invalid_body_size\"}");
    }
    char body[257] = {};
    int received = 0;
    while (received < req->content_len) {
        int r = httpd_req_recv(req, body + received, req->content_len - received);
        if (r <= 0) return SendJson(req, "400 Bad Request", "{\"ok\":false,\"error\":\"incomplete_body\"}");
        received += r;
    }
    cJSON* root = cJSON_Parse(body);
    if (!root || !cJSON_IsObject(root)) {
        if (root) cJSON_Delete(root);
        return SendJson(req, "400 Bad Request", "{\"ok\":false,\"error\":\"invalid_json\"}");
    }
    cJSON* pan = cJSON_GetObjectItemCaseSensitive(root, "pan");
    cJSON* tilt = cJSON_GetObjectItemCaseSensitive(root, "tilt");
    cJSON* speed = cJSON_GetObjectItemCaseSensitive(root, "speed_ms");
    const bool valid = cJSON_IsNumber(pan) && cJSON_IsNumber(tilt) &&
        (!speed || cJSON_IsNumber(speed)) && pan->valuedouble == pan->valueint &&
        tilt->valuedouble == tilt->valueint && (!speed || speed->valuedouble == speed->valueint);
    const int p = valid ? pan->valueint : 90;
    const int t = valid ? tilt->valueint : 90;
    const int ms = (valid && speed) ? speed->valueint : 350;
    cJSON_Delete(root);
    if (!valid || p < 45 || p > 135 || t < 45 || t > 135 || ms < 100 || ms > 2000) {
        return SendJson(req, "422 Unprocessable Entity", "{\"ok\":false,\"error\":\"pan_tilt_out_of_range\"}");
    }
    OttoPanTilt* controller = GetOttoPanTiltController();
    if (!controller || !controller->IsEnabled()) {
        return SendJson(req, "409 Conflict", "{\"ok\":false,\"error\":\"servos_not_configured\"}");
    }
    if (!controller->SetAngles(p, t, ms)) {
        return SendJson(req, "503 Service Unavailable", "{\"ok\":false,\"error\":\"servo_move_failed\"}");
    }
    return SendJson(req, "200 OK", "{\"ok\":true,\"pan_tilt\":\"updated\"}");
}

esp_err_t WebSocketControlServer::restart_post_handler(httpd_req_t* req) {
    SendJson(req, "200 OK", "{\"ok\":true,\"restarting\":true}");
    if (xTaskCreate(RestartTask, "otto_restart", 2048, nullptr, 5, nullptr) != pdPASS) {
        ESP_LOGE(TAG, "Unable to create restart task");
        return ESP_FAIL;
    }
    return ESP_OK;
}

void WebSocketControlServer::Stop() {
    if (server_handle_) {
        httpd_stop(server_handle_);
        server_handle_ = nullptr;
        clients_.clear();
        ESP_LOGI(TAG, "WebSocket server stopped");
    }
}

void WebSocketControlServer::HandleMessage(httpd_req_t *req, const char* data, size_t len) {
    if (data == nullptr || len == 0) {
        ESP_LOGE(TAG, "Invalid message: data is null or len is 0");
        return;
    }
    
    if (len > 4096) {
        ESP_LOGE(TAG, "Message too long: %zu bytes", len);
        return;
    }
    
    char* temp_buf = (char*)malloc(len + 1);
    if (temp_buf == nullptr) {
        ESP_LOGE(TAG, "Failed to allocate memory");
        return;
    }
    memcpy(temp_buf, data, len);
    temp_buf[len] = '\0';
    
    cJSON* root = cJSON_Parse(temp_buf);
    free(temp_buf);
    
    if (root == nullptr) {
        ESP_LOGE(TAG, "Failed to parse JSON");
        return;
    }

    int sock_fd = httpd_req_to_sockfd(req);
    uint64_t client_id = GetClientId(req);
    if (client_id == 0) {
        ESP_LOGW(TAG, "Ignoring message from unknown client: %d", sock_fd);
        cJSON_Delete(root);
        return;
    }

    auto response_sender = [sock_fd, client_id](const std::string& payload) {
        if (WebSocketControlServer::instance_) {
            WebSocketControlServer::instance_->SendMessage(sock_fd, client_id, payload);
        }
    };

    // 支持两种格式：
    // 1. 完整格式：{"type":"mcp","payload":{...}}
    // 2. 简化格式：直接是MCP payload对象
    
    cJSON* payload = nullptr;
    cJSON* type = cJSON_GetObjectItem(root, "type");
    
    if (type && cJSON_IsString(type) && strcmp(type->valuestring, "mcp") == 0) {
        payload = cJSON_GetObjectItem(root, "payload");
        if (payload != nullptr) {
            cJSON_DetachItemViaPointer(root, payload);
            McpServer::GetInstance().ParseMessage(payload, response_sender);
            cJSON_Delete(payload); 
        }
    } else {
        payload = cJSON_Duplicate(root, 1);
        if (payload != nullptr) {
            McpServer::GetInstance().ParseMessage(payload, response_sender);
            cJSON_Delete(payload);
        }
    }
    
    if (payload == nullptr) {
        ESP_LOGE(TAG, "Invalid message format or failed to parse");
    }

    cJSON_Delete(root);
}

void WebSocketControlServer::AddClient(httpd_req_t *req) {
    int sock_fd = httpd_req_to_sockfd(req);
    if (clients_.find(sock_fd) == clients_.end()) {
        uint64_t client_id = ++next_client_id_;
        clients_[sock_fd] = ClientInfo{
            .client_id = client_id
        };
        ESP_LOGI(TAG, "Client connected: %d id=%llu (total: %zu)", sock_fd, (unsigned long long)client_id, clients_.size());
    }
}

void WebSocketControlServer::RemoveClient(httpd_req_t *req) {
    int sock_fd = httpd_req_to_sockfd(req);
    clients_.erase(sock_fd);
    ESP_LOGI(TAG, "Client disconnected: %d (total: %zu)", sock_fd, clients_.size());
}

size_t WebSocketControlServer::GetClientCount() const {
    return clients_.size();
}

uint64_t WebSocketControlServer::GetClientId(httpd_req_t *req) const {
    int sock_fd = httpd_req_to_sockfd(req);
    auto it = clients_.find(sock_fd);
    if (it == clients_.end()) {
        return 0;
    }
    return it->second.client_id;
}

struct WsBroadcastJob {
    httpd_handle_t server;
    int fd;
    char* payload;
    size_t len;
};

static void ws_broadcast_send_job(void* arg) {
    WsBroadcastJob* job = static_cast<WsBroadcastJob*>(arg);

    httpd_ws_frame_t ws_pkt = {};
    ws_pkt.type = HTTPD_WS_TYPE_TEXT;
    ws_pkt.payload = reinterpret_cast<uint8_t*>(job->payload);
    ws_pkt.len = job->len;
    ws_pkt.final = true;

    esp_err_t ret = httpd_ws_send_frame_async(job->server, job->fd, &ws_pkt);
    if (ret != ESP_OK) {
        ESP_LOGE("WSControl", "BroadcastMessage: send failed fd=%d err=%d", job->fd, ret);
    }

    free(job->payload);
    free(job);
}

void WebSocketControlServer::BroadcastMessage(const std::string& message) {
    if (!server_handle_ || clients_.empty()) {
        return;
    }

    for (auto& [fd, client] : clients_) {
        SendMessage(fd, client.client_id, message);
    }
}

void WebSocketControlServer::SendMessage(int sock_fd, uint64_t client_id, const std::string& message) {
    if (!server_handle_) {
        return;
    }

    auto client = clients_.find(sock_fd);
    if (client == clients_.end() || client->second.client_id != client_id) {
        ESP_LOGW(TAG, "Skip send to stale client fd=%d id=%llu", sock_fd, (unsigned long long)client_id);
        return;
    }

    WsBroadcastJob* job = static_cast<WsBroadcastJob*>(malloc(sizeof(WsBroadcastJob)));
    if (!job) {
        ESP_LOGE(TAG, "SendMessage: failed to allocate job");
        return;
    }

    job->server = server_handle_;
    job->fd = sock_fd;
    job->len = message.length();
    job->payload = static_cast<char*>(malloc(message.length() + 1));
    if (!job->payload) {
        ESP_LOGE(TAG, "SendMessage: failed to allocate payload");
        free(job);
        return;
    }
    memcpy(job->payload, message.c_str(), message.length());
    job->payload[message.length()] = '\0';

    esp_err_t ret = httpd_queue_work(server_handle_, ws_broadcast_send_job, job);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "SendMessage: httpd_queue_work failed fd=%d err=%d", sock_fd, ret);
        free(job->payload);
        free(job);
    }
}
