#pragma once
#include <driver/gpio.h>
#include <driver/i2c_master.h>
#include <cstdint>
#include <string>

class OttoLcd1602 {
public:
    OttoLcd1602(gpio_num_t sda, gpio_num_t scl, uint8_t address);
    ~OttoLcd1602();
    bool Initialize();
    bool WriteText(const std::string& text);
private:
    bool ExpanderWrite(uint8_t value);
    bool Write4Bits(uint8_t value, bool rs);
    bool SendByte(uint8_t value, bool rs);
    void PulseEnable(uint8_t value);
    gpio_num_t sda_, scl_;
    uint8_t address_;
    uint8_t backlight_ = 0x08;
    i2c_master_bus_handle_t bus_ = nullptr;
    i2c_master_dev_handle_t device_ = nullptr;
    bool ready_ = false;
};

void RegisterOttoLcd1602(OttoLcd1602* lcd);
void OttoLcd1602Write(const char* text);
