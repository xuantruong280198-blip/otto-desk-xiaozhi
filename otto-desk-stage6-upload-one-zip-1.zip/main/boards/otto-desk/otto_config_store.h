#ifndef OTTO_DESK_CONFIG_STORE_H
#define OTTO_DESK_CONFIG_STORE_H

#include <cJSON.h>
#include <nvs.h>
#include <esp_log.h>
#include <cstring>
#include <cstdlib>
#include "config.h"

namespace otto_desk_config {
static constexpr const char* kNamespace = "otto_cfg";
static constexpr const char* kKey = "hardware_json";
static constexpr size_t kMaxJson = 4096;
static constexpr const char* kTag = "OttoCfg";

struct PinField { const char* key; gpio_num_t HardwareConfig::*member; };
static constexpr PinField kPinFields[] = {
    {"display_clk", &HardwareConfig::display_clk_pin},
    {"display_mosi", &HardwareConfig::display_mosi_pin},
    {"display_dc", &HardwareConfig::display_dc_pin},
    {"display_rst", &HardwareConfig::display_rst_pin},
    {"display_backlight", &HardwareConfig::display_backlight_pin},
    {"display_cs", &HardwareConfig::display_cs_pin},
    {"mic_ws", &HardwareConfig::audio_i2s_mic_gpio_ws},
    {"mic_sck", &HardwareConfig::audio_i2s_mic_gpio_sck},
    {"mic_din", &HardwareConfig::audio_i2s_mic_gpio_din},
    {"speaker_dout", &HardwareConfig::audio_i2s_spk_gpio_dout},
    {"speaker_bclk", &HardwareConfig::audio_i2s_spk_gpio_bclk},
    {"speaker_lrck", &HardwareConfig::audio_i2s_spk_gpio_lrck},
    {"i2c_sda", &HardwareConfig::i2c_sda_pin},
    {"i2c_scl", &HardwareConfig::i2c_scl_pin},
    {"pan_servo", &HardwareConfig::pan_servo_pin},
    {"tilt_servo", &HardwareConfig::tilt_servo_pin},
};

inline bool IsUsableGpio(int pin) {
    // ESP32-S3 GPIO matrix: 0..21 and 26..48. GPIO22..25 do not exist.
    // GPIO26..32 are reserved for flash/PSRAM on this module and are excluded.
    if (pin == -1) return true;
    if (!((pin >= 1 && pin <= 18) || pin == 21 ||
          (pin >= 38 && pin <= 42) || pin == 47 || pin == 48)) return false;
    return true;
}

inline bool ApplyJson(const char* json, HardwareConfig& cfg) {
    cJSON* root = cJSON_Parse(json);
    if (!root || !cJSON_IsObject(root)) { if (root) cJSON_Delete(root); return false; }
    cJSON* version = cJSON_GetObjectItemCaseSensitive(root, "config_version");
    cJSON* hardware = cJSON_GetObjectItemCaseSensitive(root, "hardware");
    if (!cJSON_IsNumber(version) || version->valueint != 1 || !cJSON_IsObject(hardware)) {
        cJSON_Delete(root); return false;
    }
    cJSON* lcd_enabled = cJSON_GetObjectItemCaseSensitive(hardware, "lcd1602_enabled");
    if (lcd_enabled) {
        if (!cJSON_IsBool(lcd_enabled)) { cJSON_Delete(root); return false; }
        cfg.lcd1602_enabled = cJSON_IsTrue(lcd_enabled);
    }
    cJSON* lcd_address = cJSON_GetObjectItemCaseSensitive(hardware, "lcd1602_address");
    if (lcd_address) {
        if (!cJSON_IsNumber(lcd_address) || lcd_address->valuedouble != lcd_address->valueint ||
            lcd_address->valueint < 0x08 || lcd_address->valueint > 0x77) {
            cJSON_Delete(root); return false;
        }
        cfg.lcd1602_i2c_address = static_cast<uint8_t>(lcd_address->valueint);
    }
    for (const auto& field : kPinFields) {
        cJSON* item = cJSON_GetObjectItemCaseSensitive(hardware, field.key);
        if (!item) continue;
        if (!cJSON_IsNumber(item) || item->valuedouble != item->valueint || !IsUsableGpio(item->valueint)) {
            cJSON_Delete(root); return false;
        }
        cfg.*(field.member) = static_cast<gpio_num_t>(item->valueint);
    }
    // Check the complete resulting pin map, including unchanged board defaults.
    int assigned[sizeof(kPinFields) / sizeof(kPinFields[0])];
    size_t assigned_count = 0;
    for (const auto& field : kPinFields) {
        const int pin = static_cast<int>(cfg.*(field.member));
        if (pin < 0) continue;
        if (!IsUsableGpio(pin)) { cJSON_Delete(root); return false; }
        for (size_t i = 0; i < assigned_count; ++i) {
            if (assigned[i] == pin) { cJSON_Delete(root); return false; }
        }
        assigned[assigned_count++] = pin;
    }
    if ((cfg.pan_servo_pin == GPIO_NUM_NC) != (cfg.tilt_servo_pin == GPIO_NUM_NC)) {
        cJSON_Delete(root); return false;
    }
    if (cfg.lcd1602_enabled && (cfg.i2c_sda_pin == GPIO_NUM_NC || cfg.i2c_scl_pin == GPIO_NUM_NC)) {
        cJSON_Delete(root); return false;
    }
    cJSON_Delete(root);
    return true;
}

inline bool Load(HardwareConfig& cfg) {
    nvs_handle_t handle;
    esp_err_t err = nvs_open(kNamespace, NVS_READONLY, &handle);
    if (err == ESP_ERR_NVS_NOT_FOUND) return true;
    if (err != ESP_OK) { ESP_LOGW(kTag, "NVS open failed: %s", esp_err_to_name(err)); return false; }
    size_t size = 0;
    err = nvs_get_str(handle, kKey, nullptr, &size);
    if (err == ESP_ERR_NVS_NOT_FOUND) { nvs_close(handle); return true; }
    if (err != ESP_OK || size < 2 || size > kMaxJson + 1) {
        nvs_close(handle); ESP_LOGW(kTag, "Stored config size invalid"); return false;
    }
    char* json = static_cast<char*>(malloc(size));
    if (!json) { nvs_close(handle); return false; }
    err = nvs_get_str(handle, kKey, json, &size);
    nvs_close(handle);
    if (err != ESP_OK) { free(json); return false; }
    HardwareConfig candidate = cfg;
    const bool valid = ApplyJson(json, candidate);
    free(json);
    if (!valid) { ESP_LOGW(kTag, "Stored hardware config invalid; using board defaults"); return false; }
    cfg = candidate;
    ESP_LOGI(kTag, "Stored hardware GPIO config applied");
    return true;
}
} // namespace otto_desk_config
#endif
