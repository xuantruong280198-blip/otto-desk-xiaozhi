#include "otto_lcd1602.h"
#include <esp_err.h>
#include <esp_log.h>
#include <esp_rom_sys.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <algorithm>

namespace { constexpr char TAG[] = "OttoLCD1602"; OttoLcd1602* g_lcd = nullptr; }

OttoLcd1602::OttoLcd1602(gpio_num_t sda, gpio_num_t scl, uint8_t address)
    : sda_(sda), scl_(scl), address_(address) {}

OttoLcd1602::~OttoLcd1602() {
    if (device_) i2c_master_bus_rm_device(device_);
    if (bus_) i2c_del_master_bus(bus_);
}

bool OttoLcd1602::ExpanderWrite(uint8_t value) {
    if (!device_) return false;
    value |= backlight_;
    return i2c_master_transmit(device_, &value, 1, 100) == ESP_OK;
}

void OttoLcd1602::PulseEnable(uint8_t value) {
    ExpanderWrite(value | 0x04);
    esp_rom_delay_us(1);
    ExpanderWrite(value & static_cast<uint8_t>(~0x04));
    esp_rom_delay_us(50);
}

bool OttoLcd1602::Write4Bits(uint8_t value, bool rs) {
    uint8_t out = (value & 0xF0) | (rs ? 0x01 : 0x00);
    if (!ExpanderWrite(out)) return false;
    PulseEnable(out);
    return true;
}

bool OttoLcd1602::SendByte(uint8_t value, bool rs) {
    return Write4Bits(value & 0xF0, rs) && Write4Bits((value << 4) & 0xF0, rs);
}

bool OttoLcd1602::Initialize() {
    if (sda_ == GPIO_NUM_NC || scl_ == GPIO_NUM_NC || sda_ == scl_) return false;
    i2c_master_bus_config_t bus_cfg = {};
    bus_cfg.i2c_port = I2C_NUM_0;
    bus_cfg.sda_io_num = sda_;
    bus_cfg.scl_io_num = scl_;
    bus_cfg.clk_source = I2C_CLK_SRC_DEFAULT;
    bus_cfg.glitch_ignore_cnt = 7;
    bus_cfg.flags.enable_internal_pullup = 1;
    esp_err_t err = i2c_new_master_bus(&bus_cfg, &bus_);
    if (err != ESP_OK) { ESP_LOGE(TAG, "I2C bus init failed: %s", esp_err_to_name(err)); return false; }
    i2c_device_config_t dev_cfg = {};
    dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev_cfg.device_address = address_;
    dev_cfg.scl_speed_hz = 100000;
    err = i2c_master_bus_add_device(bus_, &dev_cfg, &device_);
    if (err != ESP_OK) { ESP_LOGE(TAG, "I2C LCD add failed: %s", esp_err_to_name(err)); return false; }
    vTaskDelay(pdMS_TO_TICKS(50));
    // HD44780 4-bit initialization sequence via PCF8574 backpack.
    Write4Bits(0x30, false); vTaskDelay(pdMS_TO_TICKS(5));
    Write4Bits(0x30, false); esp_rom_delay_us(150);
    Write4Bits(0x30, false); Write4Bits(0x20, false);
    SendByte(0x28, false); // 4-bit, 2-line, 5x8
    SendByte(0x0C, false); // display on, cursor off
    SendByte(0x06, false); // increment cursor
    SendByte(0x01, false); vTaskDelay(pdMS_TO_TICKS(3));
    ready_ = true;
    ESP_LOGI(TAG, "LCD1602 ready at I2C address 0x%02X", address_);
    return true;
}

bool OttoLcd1602::WriteText(const std::string& text) {
    if (!ready_) return false;
    if (!SendByte(0x80, false)) return false;
    for (int i = 0; i < 16; ++i) {
        uint8_t ch = i < static_cast<int>(text.size()) ? static_cast<uint8_t>(text[i]) : ' ';
        if (ch < 0x20 || ch > 0x7E) ch = '?'; // HD44780 ROM is not UTF-8/Vietnamese.
        if (!SendByte(ch, true)) return false;
    }
    if (!SendByte(0xC0, false)) return false;
    const size_t second = text.size() > 16 ? 16 : text.size();
    for (int i = 0; i < 16; ++i) {
        size_t pos = second + i;
        uint8_t ch = pos < text.size() ? static_cast<uint8_t>(text[pos]) : ' ';
        if (ch < 0x20 || ch > 0x7E) ch = '?';
        if (!SendByte(ch, true)) return false;
    }
    return true;
}

void RegisterOttoLcd1602(OttoLcd1602* lcd) { g_lcd = lcd; }
void OttoLcd1602Write(const char* text) { if (g_lcd && text) g_lcd->WriteText(text); }
