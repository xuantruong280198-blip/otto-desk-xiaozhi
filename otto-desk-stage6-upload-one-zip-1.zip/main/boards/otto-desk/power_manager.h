#ifndef __POWER_MANAGER_H__
#define __POWER_MANAGER_H__

#include <cstdint>

// Otto Desk is powered from USB and has no battery voltage divider or
// charging-detect circuit connected. Do not initialize/read an ADC channel:
// doing so reports a floating input as 0% and causes a false low-battery UI.
class PowerManager {
public:
    explicit PowerManager(...) {}
    ~PowerManager() = default;

    bool IsCharging() const { return false; }
    uint8_t GetBatteryLevel() const { return 0; }

    static void PauseBatteryUpdate() {}
    static void ResumeBatteryUpdate() {}
};

#endif  // __POWER_MANAGER_H__
