#include "gemini_live_transport.h"

#include <algorithm>
#include <cstring>
#include <esp_log.h>
#include <mbedtls/base64.h>
#include <cJSON.h>
#include "board.h"

#define TAG "OpenAILive"
static constexpr const char* kOpenAILiveEndpoint = "wss://api.openai.com/v1/live/sessions";

GeminiLiveTransport::GeminiLiveTransport() = default;
GeminiLiveTransport::~GeminiLiveTransport() { Disconnect(); }

std::string GeminiLiveTransport::Base64Encode(const uint8_t* data, size_t len) {
    size_t needed = 0;
    int rc = mbedtls_base64_encode(nullptr, 0, &needed, data, len);
    if (rc != MBEDTLS_ERR_BASE64_BUFFER_TOO_SMALL && rc != 0) return {};
    std::string encoded(needed, '\0');
    if (mbedtls_base64_encode(reinterpret_cast<unsigned char*>(encoded.data()), encoded.size(), &needed, data, len) != 0) return {};
    encoded.resize(needed);
    return encoded;
}

bool GeminiLiveTransport::Base64Decode(const std::string& text, std::vector<uint8_t>& out) {
    size_t needed = 0;
    int rc = mbedtls_base64_decode(nullptr, 0, &needed, reinterpret_cast<const unsigned char*>(text.data()), text.size());
    if (rc != MBEDTLS_ERR_BASE64_BUFFER_TOO_SMALL && rc != 0) return false;
    if (needed == 0 || needed > 64 * 1024) return false;
    out.resize(needed);
    rc = mbedtls_base64_decode(out.data(), out.size(), &needed, reinterpret_cast<const unsigned char*>(text.data()), text.size());
    if (rc != 0) { out.clear(); return false; }
    out.resize(needed);
    return true;
}

bool GeminiLiveTransport::Connect(const std::string& api_key, const std::string& model,
                                  const std::string& system_instruction) {
    if (api_key.empty() || model.empty()) return false;
    Disconnect();
    auto network = Board::GetInstance().GetNetwork();
    websocket_ = network->CreateWebSocket(1);
    if (!websocket_) return false;
    setup_complete_.store(false);
    websocket_->SetHeader("Authorization", ("Bearer " + api_key).c_str());
    websocket_->OnData([this](const char* data, size_t len, bool binary) { HandleServerMessage(data, len, binary); });
    websocket_->OnDisconnected([this]() {
        setup_complete_.store(false);
        if (on_state_) on_state_("disconnected");
    });
    if (!websocket_->Connect(kOpenAILiveEndpoint)) {
        ESP_LOGE(TAG, "OpenAI Live WebSocket connection failed; API key is not logged");
        websocket_.reset();
        return false;
    }
    if (on_state_) on_state_("connected");
    if (!SendSetup(model, system_instruction)) { Disconnect(); return false; }
    return true;
}

bool GeminiLiveTransport::SendSetup(const std::string& model, const std::string& instruction) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "type", "session.start");
    cJSON* session = cJSON_AddObjectToObject(root, "session");
    cJSON_AddStringToObject(session, "model", model.c_str());
    cJSON_AddStringToObject(session, "instructions", instruction.c_str());
    cJSON* audio = cJSON_AddObjectToObject(session, "audio");
    cJSON* format = cJSON_AddObjectToObject(audio, "format");
    cJSON_AddStringToObject(format, "type", "audio/pcm");
    cJSON_AddNumberToObject(format, "rate", 24000);
    cJSON* output = cJSON_AddObjectToObject(audio, "output");
    cJSON_AddStringToObject(output, "voice", "marin");
    char* raw = cJSON_PrintUnformatted(root);
    const bool ok = raw && SendJson(raw);
    if (raw) cJSON_free(raw);
    cJSON_Delete(root);
    return ok;
}

bool GeminiLiveTransport::SendJson(const std::string& json) {
    return websocket_ && websocket_->IsConnected() && websocket_->Send(json);
}

bool GeminiLiveTransport::SendPcm16k(const int16_t* samples, size_t sample_count) {
    if (!setup_complete_.load() || !samples || sample_count == 0 || sample_count > 4096) return false;
    // The mic service captures mono PCM16 at 16 kHz. GPT-Live is configured for
    // 24 kHz, so linearly resample before encoding the raw PCM bytes.
    const size_t out_count = (sample_count * 3) / 2;
    std::vector<int16_t> resampled(out_count);
    for (size_t i = 0; i < out_count; ++i) {
        const float src = static_cast<float>(i) * (2.0f / 3.0f);
        const size_t a = std::min<size_t>(static_cast<size_t>(src), sample_count - 1);
        const size_t b = std::min(a + 1, sample_count - 1);
        const float frac = src - static_cast<float>(a);
        resampled[i] = static_cast<int16_t>(samples[a] + (samples[b] - samples[a]) * frac);
    }
    std::string b64 = Base64Encode(reinterpret_cast<const uint8_t*>(resampled.data()), resampled.size() * sizeof(int16_t));
    if (b64.empty()) return false;
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "type", "session.input_audio.append");
    cJSON_AddStringToObject(root, "audio", b64.c_str());
    char* raw = cJSON_PrintUnformatted(root);
    bool ok = raw && SendJson(raw);
    if (raw) cJSON_free(raw);
    cJSON_Delete(root);
    return ok;
}

void GeminiLiveTransport::HandleServerMessage(const char* data, size_t len, bool binary) {
    if (binary || !data || len == 0) return;
    cJSON* root = cJSON_ParseWithLength(data, len);
    if (!root) return;
    cJSON* type = cJSON_GetObjectItem(root, "type");
    const std::string event = cJSON_IsString(type) ? type->valuestring : "";
    if (event == "session.started") {
        setup_complete_.store(true);
        if (on_state_) on_state_("ready");
    } else if (event == "session.output_audio.delta") {
        cJSON* delta = cJSON_GetObjectItem(root, "delta");
        if (cJSON_IsString(delta)) {
            std::vector<uint8_t> pcm;
            if (Base64Decode(delta->valuestring, pcm) && (pcm.size() % 2 == 0)) {
                std::vector<int16_t> samples(pcm.size() / 2);
                memcpy(samples.data(), pcm.data(), pcm.size());
                if (!samples.empty()) {
                    if (on_state_) on_state_("speaking");
                    if (on_pcm_) on_pcm_(std::move(samples));
                }
            }
        }
    } else if (event == "session.input_transcript.delta") {
        if (on_state_) on_state_("listening");
    } else if (event == "error") {
        cJSON* err = cJSON_GetObjectItem(root, "error");
        cJSON* message = err ? cJSON_GetObjectItem(err, "message") : nullptr;
        ESP_LOGE(TAG, "Live API returned an error: %s", cJSON_IsString(message) ? message->valuestring : "unspecified");
        if (on_state_) on_state_("api_error");
    } else if (event == "session.closed") {
        setup_complete_.store(false);
        if (on_state_) on_state_("disconnected");
    }
    cJSON_Delete(root);
}

void GeminiLiveTransport::Disconnect() {
    setup_complete_.store(false);
    websocket_.reset();
}

bool GeminiLiveTransport::IsConnected() const {
    return websocket_ && websocket_->IsConnected();
}
