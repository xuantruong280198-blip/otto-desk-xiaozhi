#include "gemini_live_transport.h"

#include <algorithm>
#include <cstring>
#include <esp_log.h>
#include <mbedtls/base64.h>
#include <cJSON.h>
#include "board.h"

#define TAG "GeminiLive"
static constexpr const char* kGeminiLiveEndpoint =
    "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";

GeminiLiveTransport::GeminiLiveTransport() = default;
GeminiLiveTransport::~GeminiLiveTransport() { Disconnect(); }

std::string GeminiLiveTransport::UrlEncode(const std::string& value) {
    static const char hex[] = "0123456789ABCDEF";
    std::string out;
    for (unsigned char c : value) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
            out.push_back(static_cast<char>(c));
        } else {
            out.push_back('%'); out.push_back(hex[c >> 4]); out.push_back(hex[c & 15]);
        }
    }
    return out;
}

std::string GeminiLiveTransport::Base64Encode(const uint8_t* data, size_t len) {
    size_t needed = 0;
    if (mbedtls_base64_encode(nullptr, 0, &needed, data, len) != MBEDTLS_ERR_BASE64_BUFFER_TOO_SMALL && needed == 0) return {};
    std::string encoded(needed, '\0');
    if (mbedtls_base64_encode(reinterpret_cast<unsigned char*>(encoded.data()), encoded.size(),
                              &needed, data, len) != 0) return {};
    encoded.resize(needed);
    return encoded;
}

bool GeminiLiveTransport::Base64Decode(const std::string& text, std::vector<uint8_t>& out) {
    size_t needed = 0;
    int rc = mbedtls_base64_decode(nullptr, 0, &needed,
        reinterpret_cast<const unsigned char*>(text.data()), text.size());
    if (rc != MBEDTLS_ERR_BASE64_BUFFER_TOO_SMALL && rc != 0) return false;
    if (needed == 0 || needed > 64 * 1024) return false; // bounded message allocation
    out.resize(needed);
    rc = mbedtls_base64_decode(out.data(), out.size(), &needed,
        reinterpret_cast<const unsigned char*>(text.data()), text.size());
    if (rc != 0) { out.clear(); return false; }
    out.resize(needed);
    return true;
}

bool GeminiLiveTransport::Connect(const std::string& api_key, const std::string& model,
                                  const std::string& system_instruction) {
    if (api_key.empty() || model.empty()) return false;
    Disconnect();
    auto network = Board::GetInstance().GetNetwork();
    websocket_ = network->CreateWebSocket(1);
    if (!websocket_) return false;
    setup_complete_.store(false);
    const std::string url = std::string(kGeminiLiveEndpoint) + "?key=" + UrlEncode(api_key);
    websocket_->OnData([this](const char* data, size_t len, bool binary) {
        HandleServerMessage(data, len, binary);
    });
    websocket_->OnDisconnected([this]() {
        setup_complete_.store(false);
        if (on_state_) on_state_("disconnected");
    });
    auto connected = websocket_->Connect(url.c_str());
    if (!connected) {
        ESP_LOGE(TAG, "Gemini WebSocket connection failed"); // never log URL/API key
        websocket_.reset();
        return false;
    }
    if (on_state_) on_state_("connected");
    if (!SendSetup(model, system_instruction)) {
        Disconnect();
        return false;
    }
    return true;
}

bool GeminiLiveTransport::SendSetup(const std::string& model, const std::string& instruction) {
    cJSON* root = cJSON_CreateObject();
    cJSON* setup = cJSON_AddObjectToObject(root, "setup");
    cJSON_AddStringToObject(setup, "model", model.c_str());
    cJSON* generation = cJSON_AddObjectToObject(setup, "generationConfig");
    cJSON* modalities = cJSON_AddArrayToObject(generation, "responseModalities");
    cJSON_AddItemToArray(modalities, cJSON_CreateString("AUDIO"));
    cJSON* sys = cJSON_AddObjectToObject(setup, "systemInstruction");
    cJSON* parts = cJSON_AddArrayToObject(sys, "parts");
    cJSON* part = cJSON_CreateObject();
    cJSON_AddStringToObject(part, "text", instruction.c_str());
    cJSON_AddItemToArray(parts, part);
    char* raw = cJSON_PrintUnformatted(root);
    const bool ok = raw && SendJson(raw);
    if (raw) cJSON_free(raw);
    cJSON_Delete(root);
    return ok;
}

bool GeminiLiveTransport::SendJson(const std::string& json) {
    return websocket_ && websocket_->IsConnected() && websocket_->Send(json);
}

bool GeminiLiveTransport::SendPcm16k(const int16_t* samples, size_t sample_count) {
    if (!setup_complete_.load() || !samples || sample_count == 0 || sample_count > 4096) return false;
    const auto* bytes = reinterpret_cast<const uint8_t*>(samples);
    std::string b64 = Base64Encode(bytes, sample_count * sizeof(int16_t));
    if (b64.empty()) return false;
    cJSON* root = cJSON_CreateObject();
    cJSON* realtime = cJSON_AddObjectToObject(root, "realtimeInput");
    cJSON* audio = cJSON_AddObjectToObject(realtime, "audio");
    cJSON_AddStringToObject(audio, "mimeType", "audio/pcm;rate=16000");
    cJSON_AddStringToObject(audio, "data", b64.c_str());
    char* raw = cJSON_PrintUnformatted(root);
    bool ok = raw && SendJson(raw);
    if (raw) cJSON_free(raw);
    cJSON_Delete(root);
    return ok;
}

void GeminiLiveTransport::HandleServerMessage(const char* data, size_t len, bool binary) {
    if (binary || !data || len == 0) return;
    cJSON* root = cJSON_ParseWithLength(data, len);
    if (!root) return;
    if (cJSON_GetObjectItem(root, "setupComplete")) {
        setup_complete_.store(true);
        if (on_state_) on_state_("ready");
    }
    cJSON* server = cJSON_GetObjectItem(root, "serverContent");
    if (server) {
        if (cJSON_IsTrue(cJSON_GetObjectItem(server, "interrupted"))) {
            if (on_interrupt_) on_interrupt_();
            if (on_state_) on_state_("interrupted");
        }
        // Translate Gemini server events into stable robot-facing states.
        // Audio chunks indicate active model speech; waitingForInput means the
        // model has yielded the turn and the robot can return to listening.
        cJSON* waiting = cJSON_GetObjectItem(server, "waitingForInput");
        if (cJSON_IsTrue(waiting) && on_state_) on_state_("listening");

        cJSON* turn = cJSON_GetObjectItem(server, "modelTurn");
        cJSON* contents = turn ? cJSON_GetObjectItem(turn, "parts") : nullptr;
        if (cJSON_IsArray(contents)) {
            cJSON* item = nullptr;
            cJSON_ArrayForEach(item, contents) {
                cJSON* inline_data = cJSON_GetObjectItem(item, "inlineData");
                cJSON* mime = inline_data ? cJSON_GetObjectItem(inline_data, "mimeType") : nullptr;
                cJSON* payload = inline_data ? cJSON_GetObjectItem(inline_data, "data") : nullptr;
                if (cJSON_IsString(mime) && cJSON_IsString(payload) &&
                    std::string(mime->valuestring).find("audio/pcm") == 0) {
                    std::vector<uint8_t> pcm;
                    if (Base64Decode(payload->valuestring, pcm) && (pcm.size() % 2 == 0)) {
                        std::vector<int16_t> samples(pcm.size() / 2);
                        memcpy(samples.data(), pcm.data(), pcm.size());
                        if (!samples.empty() && on_state_) on_state_("speaking");
                        if (on_pcm_) on_pcm_(std::move(samples));
                    }
                }
            }
        }
        if (cJSON_IsTrue(cJSON_GetObjectItem(server, "generationComplete")) && on_state_) on_state_("generation_complete");
        if (cJSON_IsTrue(cJSON_GetObjectItem(server, "turnComplete")) && on_state_) on_state_("listening");
    }
    cJSON_Delete(root);
}

void GeminiLiveTransport::Disconnect() {
    setup_complete_.store(false);
    websocket_.reset();
}

bool GeminiLiveTransport::IsConnected() const {
    return websocket_ && websocket_->IsConnected();
}
