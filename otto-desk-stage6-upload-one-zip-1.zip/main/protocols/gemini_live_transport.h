#pragma once

#include <atomic>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <web_socket.h>

// Low-level Gemini Live WebSocket transport. Audio is raw PCM16 mono:
// uplink 16 kHz, downlink 24 kHz. This class deliberately does not own I2S.
class GeminiLiveTransport {
public:
    using PcmCallback = std::function<void(std::vector<int16_t>&&)>;
    using StateCallback = std::function<void(const std::string&)>;
    using InterruptCallback = std::function<void()>;

    GeminiLiveTransport();
    ~GeminiLiveTransport();

    bool Connect(const std::string& api_key, const std::string& model,
                 const std::string& system_instruction);
    void Disconnect();
    bool IsConnected() const;
    bool SendPcm16k(const int16_t* samples, size_t sample_count);
    void SetPcmCallback(PcmCallback cb) { on_pcm_ = std::move(cb); }
    void SetStateCallback(StateCallback cb) { on_state_ = std::move(cb); }
    void SetInterruptCallback(InterruptCallback cb) { on_interrupt_ = std::move(cb); }

private:
    std::shared_ptr<WebSocket> websocket_;
    PcmCallback on_pcm_;
    StateCallback on_state_;
    InterruptCallback on_interrupt_;
    std::atomic<bool> setup_complete_{false};

    bool SendSetup(const std::string& model, const std::string& instruction);
    bool SendJson(const std::string& json);
    void HandleServerMessage(const char* data, size_t len, bool binary);
    static std::string UrlEncode(const std::string& value);
    static std::string Base64Encode(const uint8_t* data, size_t len);
    static bool Base64Decode(const std::string& text, std::vector<uint8_t>& out);
};
