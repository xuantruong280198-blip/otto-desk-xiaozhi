#pragma once

#include <atomic>
#include <string>
#include "gemini_live_transport.h"
#include "audio_service.h"

// Owns the direct Gemini Live session and bridges the raw PCM audio service.
// The application decides when to call ConnectFromNvs()/Disconnect().
class GeminiLiveSession {
public:
    using StateCallback = std::function<void(const std::string&)>;
    explicit GeminiLiveSession(AudioService& audio);
    ~GeminiLiveSession();

    bool ConnectFromNvs(const std::string& model, const std::string& instruction);
    void Disconnect();
    bool IsConnected() const;
    void SetStateCallback(StateCallback callback) { on_state_ = std::move(callback); }

private:
    AudioService& audio_;
    GeminiLiveTransport transport_;
    StateCallback on_state_;
    std::atomic<bool> active_{false};
    static bool ReadApiKey(std::string& key);
    void HandleState(const std::string& state);
    void NotifyState(const std::string& state);
};
