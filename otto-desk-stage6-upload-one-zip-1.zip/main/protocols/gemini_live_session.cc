#include "gemini_live_session.h"

#include <algorithm>
#include <cstring>
#include <esp_log.h>
#include <nvs.h>

#define TAG "GeminiSession"

extern void SetOttoGeminiHeadState(const char* state);
static constexpr const char* kNvsNamespace = "otto_cfg";
static constexpr const char* kNvsApiKey = "openai_api_key";
static constexpr size_t kMaxApiKeyBytes = 256;

GeminiLiveSession::GeminiLiveSession(AudioService& audio) : audio_(audio) {
    transport_.SetStateCallback([this](const std::string& state) { HandleState(state); });
    transport_.SetPcmCallback([this](std::vector<int16_t>&& pcm) {
        if (!active_.load() || pcm.empty()) return;
        // Keep each speaker write <= 40 ms. The audio service queue is bounded;
        // on overload we drop newest chunks rather than blocking the WS task.
        size_t offset = 0;
        while (offset < pcm.size()) {
            const size_t count = std::min<size_t>(960, pcm.size() - offset);
            std::vector<int16_t> chunk(pcm.begin() + offset, pcm.begin() + offset + count);
            if (!audio_.QueueGeminiPcm24k(std::move(chunk))) {
                ESP_LOGW(TAG, "OpenAI playback queue full; dropping audio chunk");
                break;
            }
            offset += count;
        }
    });
    transport_.SetInterruptCallback([this]() {
        // Clears buffered audio immediately. A currently executing I2S write can
        // finish its current <=40 ms chunk; no later queued chunk will play.
        audio_.FlushGeminiPlayback();
    });
}

GeminiLiveSession::~GeminiLiveSession() { Disconnect(); }

bool GeminiLiveSession::ReadApiKey(std::string& key) {
    nvs_handle_t handle;
    if (nvs_open(kNvsNamespace, NVS_READONLY, &handle) != ESP_OK) return false;
    size_t required = 0;
    esp_err_t err = nvs_get_str(handle, kNvsApiKey, nullptr, &required);
    if (err != ESP_OK || required < 20 || required > kMaxApiKeyBytes + 1) {
        nvs_close(handle);
        return false;
    }
    std::vector<char> buffer(required, '\0');
    err = nvs_get_str(handle, kNvsApiKey, buffer.data(), &required);
    nvs_close(handle);
    if (err != ESP_OK) return false;
    key.assign(buffer.data());
    // Best-effort erase temporary key storage after copying into std::string.
    std::fill(buffer.begin(), buffer.end(), '\0');
    return !key.empty();
}

bool GeminiLiveSession::ConnectFromNvs(const std::string& model, const std::string& instruction) {
    if (active_.load()) return true;
    std::string api_key;
    if (!ReadApiKey(api_key)) {
        if (on_state_) on_state_("missing_api_key");
        return false;
    }

    audio_.SetGeminiPcmCallback([this](std::vector<int16_t>&& pcm) {
        if (active_.load() && !pcm.empty()) {
            transport_.SendPcm16k(pcm.data(), pcm.size());
        }
    });
    active_.store(true);
    const bool connected = transport_.Connect(api_key, model, instruction);
    std::fill(api_key.begin(), api_key.end(), '\0');
    if (!connected) {
        active_.store(false);
        audio_.SetGeminiPcmCallback(nullptr);
        if (on_state_) on_state_("connect_failed");
        return false;
    }
    // Audio capture begins only after the server acknowledges setupComplete.
    if (on_state_) on_state_("connecting_setup");
    return true;
}

void GeminiLiveSession::HandleState(const std::string& state) {
    if (state == "ready") {
        if (active_.load()) audio_.StartGeminiLiveAudio();
    } else if (state == "disconnected") {
        audio_.StopGeminiLiveAudio();
        active_.store(false);
    }
    NotifyState(state);
}

void GeminiLiveSession::NotifyState(const std::string& state) {
    // Feed the dedicated Otto head-motion task; never move servos on the
    // WebSocket/audio callback thread.
    SetOttoGeminiHeadState(state.c_str());
    if (on_state_) on_state_(state);
}

void GeminiLiveSession::Disconnect() {
    active_.store(false);
    audio_.StopGeminiLiveAudio();
    audio_.SetGeminiPcmCallback(nullptr);
    transport_.Disconnect();
    NotifyState("disconnected");
}

bool GeminiLiveSession::IsConnected() const {
    return active_.load() && transport_.IsConnected();
}
