# Build firmware Otto Desk trên GitHub Actions

## 1. Đưa source lên repository

Giải nén gói source này. **Đưa toàn bộ nội dung bên trong thư mục project lên thư mục gốc (root) của repository GitHub**, giữ nguyên các thư mục như `main/`, `components/`, `managed_components/`, `scripts/`, `partitions/`, `.github/` và các file `CMakeLists.txt`, `sdkconfig.defaults`.

Không chỉ upload file ZIP lên GitHub; GitHub Actions cần nhìn thấy `.github/workflows/build-otto-desk.yml` ở đúng đường dẫn.

## 2. Chạy build

Sau khi commit/push lên nhánh `main`, workflow `Build Otto Desk firmware` tự chạy khi các file source liên quan thay đổi.

Có thể chạy thủ công:
1. Mở repository GitHub.
2. Chọn tab **Actions**.
3. Chọn workflow **Build Otto Desk firmware**.
4. Nhấn **Run workflow** → chọn nhánh `main` → **Run workflow**.

Workflow dùng container `espressif/idf:release-v6.1`, chạy kiểm tra build-script, rồi gọi:

```bash
source "$IDF_PATH/export.sh"
python scripts/build.py otto-desk --name otto-desk --language en-US --wake-word hiesp
```

## 3. Lấy file BIN

1. Mở lần chạy workflow vừa hoàn tất.
2. Kéo xuống **Artifacts**.
3. Tải `otto-desk-firmware-<commit-sha>`.
4. Giải nén artifact để lấy `merged-binary.bin`.

Đây là **merged image** để nạp theo đúng hướng dẫn flash của dự án. Không đổi tên hoặc nạp bằng offset tùy ý. Nếu dùng OTA qua trang web của Otto, chỉ upload đúng loại firmware mà endpoint OTA trong source yêu cầu; cần kiểm tra quy trình OTA của bản đang chạy trước khi cập nhật.

## 4. Nếu build lỗi

Mở lần chạy Actions → job `Build Otto Desk (ESP-IDF 6.1)` → mở step đỏ đầu tiên. Gửi toàn bộ log từ dòng lỗi đầu tiên (không chỉ ảnh dòng cuối) để kiểm tra.

## 5. Cấu hình phần cứng

Target hiện tại là **ESP32-S3** và board config `otto-desk`. Không chọn board Waveshare hoặc board camera khác. GPIO đang được khai báo trong `main/boards/otto-desk/`.

## Lưu ý quan trọng

- Workflow build tự động không chứng minh firmware đã chạy ổn trên phần cứng.
- Build thành công cũng không thay thế thử nghiệm mic, loa, màn hình, servo, Gemini Live và OTA.
- Không đưa Gemini API key, mật khẩu Wi-Fi hoặc token vào repository.
- Không bật log chứa bí mật khi gửi log build.
