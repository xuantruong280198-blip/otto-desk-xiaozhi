# Stage 5D — Application and web UI control

## Changes in this snapshot
- `Application` now owns a `GeminiLiveSession` instance bound to the existing `AudioService`.
- Added thread-serialized `ConnectGeminiLive`, `DisconnectGeminiLive`, and `IsGeminiLiveConnected` controls.
- Added local HTTP endpoints:
  - `GET /api/gemini-session`
  - `POST /api/gemini-session`
  - `DELETE /api/gemini-session`
- Added Connect / Disconnect controls and status polling to the Otto Desk local configuration page.
- Session startup reads the API key from NVS; it is not returned to the browser or exported to JSON.
- Selected current Gemini Developer API Live model ID: `models/gemini-3.1-flash-live-preview`.
- XiaoZhi remains the default path unless the user explicitly connects Gemini from the local page.

## Validation performed
- Checked that the new declarations have matching definitions.
- Checked that the new HTTP routes are registered and handlers are declared.
- Checked that the session source remains included in the main component CMake source list.
- Checked ZIP archive integrity after packaging.

## Not validated
- No ESP-IDF build was run.
- No firmware was flashed to the ESP32-S3 N16R8.
- No live Gemini handshake was performed from the device.
- No mic/speaker hardware, AEC, or real interruption test was performed.
- `IsGeminiLiveConnected()` indicates active WebSocket/session ownership; it does not independently prove that the `setupComplete` handshake succeeded. The session starts mic uplink only after the transport's `setupComplete` callback.

## Important safety note
The web configuration server has no authentication in this source. Keep it on a trusted private LAN. The API key is stored in NVS, which is not encrypted by default. Direct long-lived API-key use on a device exposes the key to anyone able to extract the device flash. Enable flash encryption and secure boot for a production device, and restrict access to the local config page.
