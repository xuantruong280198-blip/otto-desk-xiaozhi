# Stage 5F — Gemini to Otto head-motion synchronization

## Implemented in this source snapshot
- Added a small atomic Gemini interaction-state bridge in `otto_controller.cc`.
- `GeminiLiveSession::NotifyState` forwards state changes to the bridge.
- The existing dedicated head-motion task consumes the state and applies subtle PAN/TILT gestures for listening, thinking, speaking, interruption and disconnect.
- Servo commands remain in the head-motion task, not in the WebSocket callback.
- The normal XiaoZhi device-state motion logic resumes when Gemini state is cleared (state 0).

## Not claimed as complete
- Otto face/eye animation is not yet mapped to Gemini states; the display implementation needs a safe public state API before that can be wired without reaching into LVGL internals.
- No ESP-IDF build was run in this environment.
- No MG90S physical movement, end-stop calibration, audio timing, AEC or barge-in hardware test was run.
- Servo GPIOs 40/41 are only used if the saved hardware config enables PAN/TILT and the physical wiring matches.

## State mapping
- listening: subtle alternating pan and slight tilt
- thinking/generation_complete: return to center
- speaking: small alternating nod
- interrupted/disconnected: center

## Safety
Keep servo power on a regulated external 5V supply and share GND with ESP32. Never power MG90S from ESP32 3V3/GPIO. Start with conservative mechanical limits and verify no binding before enabling automatic motion.
