# Otto Desk custom board profile (work in progress)

This profile is derived from `main/boards/otto-robot` and is intended for the user's ESP32-S3-CAM N16R8 with the currently confirmed ST7789, INMP441, and MAX98357A wiring.

## GPIO map
- ST7789: CLK 5, MOSI 6, DC 15, RST 7, backlight 16, CS NC
- INMP441: WS 17, SCK 18, DIN 8
- MAX98357A: DOUT 42, BCLK 2, LRCK 1
- Servo pan: GPIO40 (mapped to Otto logical `left_leg`)
- Servo tilt: GPIO41 (mapped to Otto logical `right_leg`)
- Other Otto servo channels: NC

## Safety / status
- This is a source customization only. It has NOT been compiled or flashed.
- The user's JSON declares GPIO40/41 for unused TOF/OLED functions, but those devices are not physically connected per user confirmation.
- Before powering servos, use a suitable separate regulated 5V supply, connect grounds together, and verify the board exposes GPIO40/41. Do not power servos from an ESP32 GPIO or 3V3 rail.
- The two-servo mapping reuses Otto's logical `left_leg` and `right_leg` channels. The stock walking/dance action set is not yet adapted into semantic pan/tilt movements; a later step should add dedicated head movement controls and limit angles.
- Otto's camera auto-detection is disabled by selecting `OTTO_VERSION_NO_CAMERA`; this prevents its GPIO15/16 detection routine from interfering with the user's display pins.
- The no-camera profile's legacy camera pin macros remain in the source but camera initialization is not selected.
