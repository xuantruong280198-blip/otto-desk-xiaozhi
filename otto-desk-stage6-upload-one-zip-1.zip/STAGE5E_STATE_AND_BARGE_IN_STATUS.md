# Stage 5E — Gemini state events and interruption handling

## Source changes
- Map Gemini `modelTurn` audio chunks to the robot-facing `speaking` state.
- Map `waitingForInput` and `turnComplete` to `listening`.
- Map `generationComplete` to `generation_complete`.
- Preserve the `interrupted` event and flush queued speaker audio immediately.
- Notify the session state callback on explicit disconnect.

## Important limitations
- This stage exposes reliable state events from the Gemini transport/session layer. It does not yet bind those events to Otto face animation or servo movement; that needs the actual display/controller ownership path to be wired and validated.
- Gemini's `interrupted` event is server-side VAD behavior. It cannot guarantee interruption if the microphone hears the speaker poorly, if echo masks the user's voice, or if the user is already speaking at generation onset.
- AudioService can clear queued audio, but an I2S write already in progress may finish its current chunk.
- AEC / physical barge-in must be tested on the actual board with the real mic, speaker, enclosure and volume.
- Not built: ESP-IDF toolchain is unavailable in this environment. No firmware flashing or hardware test performed.
