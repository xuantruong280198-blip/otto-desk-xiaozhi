# Stage 5 status — Gemini Live direct connection

## Completed in this increment (Stage 5B)
- Added a dedicated Gemini API Key section to the Otto local configuration page.
- Added `GET /api/gemini-key` that returns only whether a key is configured; it never returns the key.
- Added `POST /api/gemini-key` to validate and store the key under NVS namespace `otto_cfg`, key `gemini_api_key`.
- Added `DELETE /api/gemini-key` to erase the stored key.
- Hardware JSON import/export remains separate and rejects a root-level `api_key`; credentials are not included in `/api/config` responses or exports.
- The temporary HTTP request buffer is cleared before freeing; the temporary C++ string is best-effort overwritten.
- The UI warns that NVS is not automatically encrypted and that the local configuration page should only be used on a trusted LAN.

## Not yet completed
- The saved key is not yet loaded into the Gemini transport from the application startup path.
- The Gemini transport is not yet selected as an active conversation protocol.
- Microphone PCM capture and speaker PCM playback are not yet connected to the transport.
- Audio queue flushing on interruption is only exposed as a callback at transport level; no live playback queue is wired yet.
- No ESP-IDF build or physical device test has been run.

## Security limitations
- NVS storage alone does not guarantee confidentiality. Flash encryption / secure boot configuration and physical-device threat model remain to be addressed.
- The existing local HTTP configuration server has no authentication or TLS in this source. Do not expose it to the public internet or an untrusted network.
- The API key is sent to Google's documented Gemini Live WebSocket endpoint as the `key` query parameter; it is not printed in firmware logs.

## Validation
- Source-level checks and ZIP integrity checks only.
- ESP-IDF build: not run (no `idf.py` available in this environment).
- Hardware test: not run.
