#!/usr/bin/env python3
"""Static quality gate for Otto Desk Gemini Live integration.

This is intentionally a source-level audit, not a substitute for an ESP-IDF
firmware build or a physical microphone/speaker/servo test.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    p = ROOT / path
    if not p.is_file():
        raise AssertionError(f"missing file: {path}")
    return p.read_text(encoding="utf-8", errors="replace")

checks = []
def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

session = read("main/protocols/gemini_live_session.cc")
transport = read("main/protocols/gemini_live_transport.cc")
controller = read("main/boards/otto-desk/otto_controller.cc")
display = read("main/boards/otto-desk/otto_emoji_display.cc")
web = read("main/boards/otto-desk/websocket_control_server.cc")
app = read("main/application.cc")
audio = read("main/audio/audio_service.cc")
cmake = read("main/CMakeLists.txt")

# Secret handling and storage consistency.
check("Gemini key uses Otto NVS namespace", 'kNvsNamespace = "otto_cfg"' in session and 'CONFIG_NVS_NAMESPACE = "otto_cfg"' in web)
check("Gemini key has dedicated NVS key", 'kNvsApiKey = "gemini_api_key"' in session and 'GEMINI_NVS_KEY = "gemini_api_key"' in web)
check("Key GET endpoint returns status only", 'configured\\":true' in web and 'nvs_get_str(nvs, GEMINI_NVS_KEY, nullptr' in web)
check("Key request buffer is cleared", 'memset(body, 0, req->content_len + 1)' in web)
check("Key is rejected from hardware JSON", 'cJSON_GetObjectItemCaseSensitive(root, "api_key")' in web and 'wifi_password' in web)

# Live audio path and interruption.
check("Mic capture starts only after ready", 'if (state == "ready")' in session and 'audio_.StartGeminiLiveAudio()' in session)
check("16 kHz mic PCM is sent to transport", 'transport_.SendPcm16k(pcm.data(), pcm.size())' in session)
check("24 kHz playback is queued", 'QueueGeminiPcm24k' in session and 'QueueGeminiPcm24k' in audio)
check("Server interruption flushes queued playback", 'SetInterruptCallback' in session and 'FlushGeminiPlayback' in session)
check("Transport handles interrupted and turn completion", '"interrupted"' in transport and '"turnComplete"' in transport)

# App, UI and Otto state mapping.
check("Application exposes connect/disconnect/status", all(x in app for x in ['ConnectGeminiLive()', 'DisconnectGeminiLive()', 'IsGeminiLiveConnected()']))
check("HTTP UI has Gemini session endpoints", all(x in web for x in ['/api/gemini-session', 'gemini_session_post_handler', 'gemini_session_delete_handler']))
check("Session state reaches Otto controller", 'SetOttoGeminiHeadState(state.c_str())' in session)
check("Otto maps listening/thinking/speaking/interrupted/disconnected", all(f'"{s}"' in controller for s in ['listening','thinking','speaking','interrupted','disconnected']))
check("Face uses public Display::SetEmotion API", 'display->SetEmotion(' in controller and 'SetEmotion("staticstate")' in display)
check("Dedicated head task remains separate", 'HeadMotionTask' in controller and 'xTaskCreate' in controller)
check("Gemini sources are registered in CMake", 'protocols/gemini_live_transport.cc' in cmake and 'protocols/gemini_live_session.cc' in cmake)

failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + (f" | {detail}" if detail else ""))
    failed += not ok
print(f"\nRESULT: {len(checks)-failed}/{len(checks)} static checks passed")
if failed:
    sys.exit(1)
